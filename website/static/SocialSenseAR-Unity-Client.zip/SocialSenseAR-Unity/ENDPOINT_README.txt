SocialSenseAR Unity Client
==========================

WebSocket Endpoint: wss://ajraj2006--cv-model-deploy-cvmodeldeploy-web.modal.run/ws

Quick Start:
1. Open this folder in Unity (Unity 6 recommended)
2. Press Play — defaults to Webcam mode
3. To switch to AR headset mode:
   Select the SocialSenseClient GameObject in the scene,
   change Input Mode to 'AR' in the Inspector.

The serverUrl field in SocialSenseClient.cs has been pre-filled:
  wss://ajraj2006--cv-model-deploy-cvmodeldeploy-web.modal.run/ws
