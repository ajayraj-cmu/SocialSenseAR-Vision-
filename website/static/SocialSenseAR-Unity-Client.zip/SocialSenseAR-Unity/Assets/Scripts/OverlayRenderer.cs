using System;
using System.Collections.Generic;
using UnityEngine;
using Socialsense;
using Meta.XR;
using Meta.XR.EnvironmentDepth;

/// <summary>
/// Decodes RLE masks from the server and composites them into a single RGBA32
/// overlay texture projected onto a sphere around the user's head.
///
/// The sphere is centered on centerEyeAnchor. The shader uses the head rotation
/// and camera intrinsics to map each sphere fragment to the correct mask pixel
/// via a pinhole projection. Edge fade prevents visible rectangular bounds.
/// </summary>
public class OverlayRenderer : MonoBehaviour
{
    [Header("Camera")]
    [Tooltip("PassthroughCameraAccess for intrinsics")]
    public PassthroughCameraAccess cameraAccess;

    [Tooltip("CenterEyeAnchor — sphere is centered here, left camera position derived from this + LensOffset")]
    public Transform centerEyeAnchor;

    [Header("Overlay Sphere")]
    [Tooltip("Radius of the overlay sphere (meters) — large values minimize stereo parallax error between camera and eyes")]
    public float sphereRadius = 50f;

    [Header("Appearance")]
    [Range(0f, 1f)]
    public float globalAlpha = 1.0f;

    [Range(0, 255)]
    public int segmentAlpha = 235;

    [Range(0f, 0.3f)]
    [Tooltip("Soft fade width at texture edges (hides rectangular FOV boundary)")]
    public float edgeFade = 0.12f;

    [Tooltip("Disable edge fade when inverted effects are active (blur everything but X)")]
    public bool disableEdgeFadeForInvertedEffects = true;

    [Header("Alignment")]
    [Tooltip("Manual pixel offset (X, Y) applied to BOTH eyes")]
    public Vector2 projectionOffset = Vector2.zero;

    [HideInInspector]
    public Vector2 rightEyeOffset = new Vector2(36f, 0f);

    [Header("Calibration")]
    [Tooltip("Enable right-stick calibration mode: A=right, B=left, right stick Y=up/down, step=2px per press")]
    public bool calibrationMode = true;

    [Range(0.5f, 10f)]
    public float calibrationStep = 2f;

    [Header("Debug")]
    [Tooltip("Show raw passthrough texture on blur sphere to verify texture is working")]
    public bool debugRawPassthrough = false;

    // Non-serialized to avoid build issues - change via code or inspector at runtime
    [System.NonSerialized]
    public int blurDebugMode = 0;

    [Header("Blur Fallback")]
    [Tooltip("Use frosted overlay fallback for blur (webcam mode) instead of passthrough blur sphere (AR mode). Set automatically by SocialSenseClient.SetWebcamMode().")]
    public bool useOverlayBlurFallback = true;


    [Header("Labels")]
    [Tooltip("Show floating 3D text labels at each segment's center")]
    public bool showLabels = true;

    [Range(0.001f, 0.015f)]
    [Tooltip("Character size for label text")]
    public float labelCharSize = 0.003f;

    [Header("Rendering")]
    [Tooltip("Draw outlines instead of filled masks (matches Python test client)")]
    public bool outlineMode = false;

    [Range(1, 5)]
    public int outlineWidth = 2;

    [Tooltip("Enable soft outline with alpha gradient at edges (0 = hard edge, 1-5 = soft gradient width in pixels). Raised to 2 for smoother borders.")]
    [Range(0, 5)]
    public int softOutlineWidth = 2;

    [Header("Mask Smoothing")]
    [Range(0, 3)]
    [Tooltip("Smoothing radius (0=off, 1=3px, 2=5px, 3=7px). Edges are remapped with smoothstep to preserve fine features.")]
    public int maskSmoothRadius = 2;

    [Header("Legacy (optional)")]
    [Tooltip("If set, disables sphere and uses this renderer instead")]
    public Renderer overlayQuad;

    // Asset class -> RGBA color
    private static readonly Dictionary<string, Color32> AssetColors = new Dictionary<string, Color32>
    {
        { "person",     new Color32(70, 130, 255, 255) },
        { "furniture",  new Color32(70, 200, 70, 255) },
        { "lighting",   new Color32(255, 220, 50, 255) },
        { "screen",     new Color32(50, 220, 220, 255) },
        { "structural", new Color32(160, 160, 160, 255) },
        { "object",     new Color32(180, 100, 255, 255) },
    };

    // Bright colors matching Python test_client (BGR->RGB converted)
    private static readonly Color32[] BrightColors = new Color32[]
    {
        new Color32(255, 255, 0, 255),
        new Color32(255, 0, 255, 255),
        new Color32(0, 255, 0, 255),
        new Color32(0, 255, 255, 255),
        new Color32(0, 128, 255, 255),
        new Color32(255, 0, 128, 255),
        new Color32(255, 128, 0, 255),
        new Color32(128, 0, 255, 255),
        new Color32(255, 255, 255, 255),
        new Color32(200, 255, 100, 255),
    };

    private static readonly Color32 DefaultColor = new Color32(200, 200, 200, 255);
    private static readonly Color32 ClearPixel = new Color32(0, 0, 0, 0);

    private Texture2D _overlayTexture;
    private Texture2D _blurMaskTexture;  // Separate texture for blur mask regions
    private Color32[] _pixelBuffer;
    private Color32[] _blurMaskBuffer;   // Buffer for blur mask texture
    private byte[] _maskTemp;
    private byte[] _maskSmooth;  // Scratch buffer for mask smoothing pass
    private int _texWidth;
    private int _texHeight;
    private Material _material;
    private Material _blurMaterial;  // Separate material for real passthrough blur
    private bool _useIntrinsics;
    private GameObject _sphereObj;
    private GameObject _blurSphereObj;  // Separate sphere for blur effect
    private Renderer _activeRenderer;
    private Renderer _blurRenderer;

    // Capture-time pose reprojection: masks are projected using the head
    // rotation from when the frame was captured, not the current rotation.
    // This makes masks world-locked instead of lagging behind head movement.
    private Quaternion _captureRotation = Quaternion.identity;
    private bool _hasCaptureRotation = false;

    // Effect transition animation
    // Key = trackId, Value = time when effect first appeared
    private Dictionary<string, float> _effectStartTimes = new Dictionary<string, float>();
    private const float EFFECT_FADE_DURATION = 0.6f;  // seconds for fade-in / edge sweep

    // Track if any inverted effect is active this frame (for edge fade control)
    private bool _hasInvertedEffectThisFrame = false;

    // 3D label pool
    private List<GameObject> _labelPool = new List<GameObject>();

    // Cached intrinsics for label inverse projection
    private Vector2 _cachedFocalLength;
    private Vector2 _cachedPrincipalPoint;
    private float _cachedActualW, _cachedActualH;
    private Quaternion _cachedCameraProjectionRot = Quaternion.identity;
    private bool _intrinsicsValid = false;

    // Shader property IDs
    private static readonly int GlobalAlphaId = Shader.PropertyToID("_GlobalAlpha");
    private static readonly int EdgeFadeId = Shader.PropertyToID("_EdgeFade");
    private static readonly int UseIntrinsicsId = Shader.PropertyToID("_UseIntrinsicsProjection");
    private static readonly int DebugModeId = Shader.PropertyToID("_DebugMode");
    private static readonly int FocalLengthId = Shader.PropertyToID("_FocalLength");
    private static readonly int PrincipalPointId = Shader.PropertyToID("_PrincipalPoint");
    private static readonly int SensorResolutionId = Shader.PropertyToID("_SensorResolution");
    private static readonly int TextureResolutionId = Shader.PropertyToID("_TextureResolution");
    private static readonly int CameraRotationMatrixId = Shader.PropertyToID("_CameraRotationMatrix");
    private static readonly int ProjectionOffsetId = Shader.PropertyToID("_ProjectionOffset");
    private static readonly int CameraWorldPosId = Shader.PropertyToID("_CameraWorldPos");
    private static readonly int RightEyeOffsetId = Shader.PropertyToID("_RightEyeOffset");
    private static readonly int UseDepthReprojectionId = Shader.PropertyToID("_UseDepthReprojection");
    private static readonly int LeftEyeWorldPosId = Shader.PropertyToID("_LeftEyeWorldPos");
    private static readonly int RightEyeWorldPosId = Shader.PropertyToID("_RightEyeWorldPos");
    private static readonly int OutOfBoundsColorId = Shader.PropertyToID("_OutOfBoundsColor");
    private static readonly int PassthroughTexId = Shader.PropertyToID("_PassthroughTex");
    private static readonly int BlurSizeId = Shader.PropertyToID("_BlurSize");
    private static readonly int OutOfBoundsAlphaId = Shader.PropertyToID("_OutOfBoundsAlpha");
    private static readonly int PassthroughTexelSizeId = Shader.PropertyToID("_PassthroughTex_TexelSize");
    private static readonly int DebugRawPassthroughId = Shader.PropertyToID("_DebugRawPassthrough");
    private static readonly int BlurDebugModeId = Shader.PropertyToID("_DebugMode");

    private bool ShouldUseOverlayBlurFallback()
    {
        return useOverlayBlurFallback;
    }

    /// <summary>
    /// Whether the renderer is currently in webcam mode (no intrinsics, overlay blur fallback).
    /// </summary>
    private bool _isWebcamMode = false;

    /// <summary>
    /// Webcam source texture, set by SocialSenseClient so we can GPU-blur it in webcam mode.
    /// </summary>
    [System.NonSerialized]
    public Texture webcamSourceTexture;

    // Blurred webcam readback for CPU compositing in webcam blur mode
    private Texture2D _blurredWebcamReadback;
    private Color32[] _blurredWebcamPixels;

    // Environment depth for stereo-correct mask reprojection
    private EnvironmentDepthManager _depthManager;
    private Transform _leftEyeAnchor;
    private Transform _rightEyeAnchor;
    private bool _depthAvailable;

    // Webcam mode: flat overlay quad instead of sphere (sphere UVs are equirectangular
    // and don't match a flat webcam image, causing distortion and misalignment).
    private GameObject _webcamOverlayQuad;
    private Renderer _webcamOverlayRenderer;
    private Material _webcamOverlayMaterial;

    /// <summary>
    /// Called by SocialSenseClient when the input mode changes.
    /// Switches the renderer between AR mode (intrinsics + real blur) and
    /// webcam mode (flat quad projection + overlay blur fallback).
    /// </summary>
    public void SetWebcamMode(bool webcamMode)
    {
        _isWebcamMode = webcamMode;

        // In webcam mode: no intrinsics available, use overlay blur fallback
        // In AR mode: use intrinsics projection and real passthrough blur
        useOverlayBlurFallback = webcamMode;
        _useIntrinsics = !webcamMode && (cameraAccess != null && centerEyeAnchor != null);

        if (_material != null)
        {
            _material.SetFloat(UseIntrinsicsId, _useIntrinsics ? 1.0f : 0.0f);
        }

        if (webcamMode)
        {
            // Disable sphere overlays — sphere UV mapping is equirectangular and
            // doesn't match the flat perspective of a webcam image.
            if (_sphereObj != null) _sphereObj.SetActive(false);
            if (_blurSphereObj != null) _blurSphereObj.SetActive(false);

            // Create/enable flat overlay quad that matches the webcam preview exactly
            EnsureWebcamOverlayQuad();
        }
        else
        {
            // Re-enable sphere for AR mode
            if (_sphereObj != null) _sphereObj.SetActive(true);

            // Disable webcam overlay quad
            if (_webcamOverlayQuad != null) _webcamOverlayQuad.SetActive(false);
        }

        Debug.Log($"[OverlayRenderer] SetWebcamMode({webcamMode}): useIntrinsics={_useIntrinsics}, blurFallback={useOverlayBlurFallback}, useQuad={webcamMode}");
    }

    /// <summary>
    /// Creates a flat overlay quad for webcam mode. Parented to the camera,
    /// positioned slightly in front of the webcam preview quad so the overlay
    /// draws on top with pixel-perfect alignment.
    /// </summary>
    private void EnsureWebcamOverlayQuad()
    {
        if (_webcamOverlayQuad != null)
        {
            _webcamOverlayQuad.SetActive(true);
            UpdateWebcamOverlayQuadSize();
            return;
        }

        Camera cam = null;
        if (centerEyeAnchor != null)
            cam = centerEyeAnchor.GetComponentInChildren<Camera>();
        if (cam == null) cam = Camera.main;
        if (cam == null)
        {
            Debug.LogWarning("[OverlayRenderer] No camera found for webcam overlay quad");
            return;
        }

        _webcamOverlayQuad = GameObject.CreatePrimitive(PrimitiveType.Quad);
        _webcamOverlayQuad.name = "WebcamOverlayQuad";

        var col = _webcamOverlayQuad.GetComponent<Collider>();
        if (col != null) Destroy(col);

        _webcamOverlayQuad.transform.SetParent(cam.transform, false);

        // Position slightly closer than webcam preview (which defaults to 2.0)
        // so the overlay renders on top of the webcam feed.
        float d = Mathf.Max(cam.nearClipPlane + 0.15f, 1.99f);
        _webcamOverlayQuad.transform.localPosition = new Vector3(0f, 0f, d);
        _webcamOverlayQuad.transform.localRotation = Quaternion.identity;

        _webcamOverlayRenderer = _webcamOverlayQuad.GetComponent<MeshRenderer>();
        _webcamOverlayRenderer.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
        _webcamOverlayRenderer.receiveShadows = false;

        // Sprites/Default has built-in alpha blending (premultiplied)
        Shader shader = Shader.Find("Sprites/Default");
        if (shader == null) shader = Shader.Find("Unlit/Transparent");

        _webcamOverlayMaterial = new Material(shader);
        _webcamOverlayMaterial.renderQueue = 4000; // On top of everything
        _webcamOverlayRenderer.material = _webcamOverlayMaterial;

        UpdateWebcamOverlayQuadSize();

        // Start hidden — no overlay data yet, and Sprites/Default renders white with null texture
        _webcamOverlayQuad.SetActive(false);

        Debug.Log($"[OverlayRenderer] Created webcam overlay quad (d={d:F3})");
    }

    /// <summary>
    /// Sizes the webcam overlay quad to match the webcam preview quad exactly,
    /// preserving the webcam's native aspect ratio so overlays align with the feed.
    /// Must use the same aspect-correction logic as SocialSenseClient.UpdateEditorPreviewQuadTransform().
    /// </summary>
    [System.NonSerialized]
    public float webcamAspectRatio = 4f / 3f;  // Set by SocialSenseClient when webcam starts

    private void UpdateWebcamOverlayQuadSize()
    {
        if (_webcamOverlayQuad == null) return;

        Camera cam = _webcamOverlayQuad.transform.parent != null
            ? _webcamOverlayQuad.transform.parent.GetComponent<Camera>() : null;
        if (cam == null) return;

        float d = _webcamOverlayQuad.transform.localPosition.z;
        float frustumH = 2f * Mathf.Tan(cam.fieldOfView * Mathf.Deg2Rad * 0.5f) * d;
        float frustumW = frustumH * cam.aspect;

        // Match the same aspect-correction as the webcam preview quad
        float w, h;
        if (webcamAspectRatio >= cam.aspect)
        {
            w = frustumW;
            h = w / webcamAspectRatio;
        }
        else
        {
            h = frustumH;
            w = h * webcamAspectRatio;
        }

        _webcamOverlayQuad.transform.localScale = new Vector3(w, h, 1f);
    }

    // Current effect color for inverted effects (used for out-of-bounds shader fill)
    private Color _currentInvertedEffectColor = Color.clear;

    // Track if we have an active blur effect this frame
    private bool _hasBlurEffectThisFrame = false;
    private float _currentBlurIntensity = 0f;
    private bool _isBlurInverted = false;  // True when blur is inverted (blur everything except X)

    // Two-pass Gaussian blur pipeline
    private RenderTexture _blurTempRT;        // Intermediate RT after horizontal pass
    private RenderTexture _blurredPassthroughRT; // Final blurred RT after vertical pass
    private Material _blurHorizontalMat;      // Horizontal blur material
    private Material _blurVerticalMat;        // Vertical blur material
    private int _blurRTWidth;
    private int _blurRTHeight;

    // Persistent inverted blur state (keeps blur active when target not detected)
    private bool _persistentInvertedBlur = false;
    private float _persistentBlurIntensity = 0f;

    // When true, blur is completely disabled until a new blur effect is explicitly set
    private bool _blurFullyDisabled = false;

    void Start()
    {
        if (overlayQuad != null)
        {
            Debug.Log("[OverlayRenderer] MODE: Legacy quad");
            _activeRenderer = overlayQuad;
            _material = overlayQuad.material;
        }
        else
        {
            Debug.Log("[OverlayRenderer] MODE: Sphere");
            CreateOverlaySphere();
        }

        Debug.Log($"[OverlayRenderer] centerEyeAnchor={(centerEyeAnchor != null ? centerEyeAnchor.name : "NULL")} " +
                  $"cameraAccess={(cameraAccess != null ? "set" : "NULL")} " +
                  $"material={(_material != null ? "OK" : "NULL")} " +
                  $"renderer={(_activeRenderer != null ? "OK" : "NULL")} " +
                  $"outlineMode={outlineMode}");

        // Force calibrated right-eye offset — compensates for monocular camera parallax.
        // The mask comes from the left camera, so the right eye (which is ~63mm away)
        // needs a pixel offset that depends on typical viewing distance.
        // 36px works well for ~1.5-2m viewing distance. Use right controller to calibrate.
        rightEyeOffset = new Vector2(36f, 0f);

        _useIntrinsics = !_isWebcamMode && (cameraAccess != null && centerEyeAnchor != null);

        // Default blur fallback: if no intrinsics, use overlay blur
        if (!_useIntrinsics)
            useOverlayBlurFallback = true;

        if (_material != null)
        {
            _material.SetFloat(UseIntrinsicsId, _useIntrinsics ? 1.0f : 0.0f);
            _material.SetFloat(DebugModeId, 0.0f);
            _material.SetFloat(EdgeFadeId, edgeFade);
        }

        if (!_useIntrinsics)
        {
            Debug.LogWarning("[OverlayRenderer] cameraAccess or centerEyeAnchor missing, or in webcam mode — falling back to UV mode");
        }

        // --- Environment Depth setup for stereo-correct reprojection ---
        InitializeDepthReprojection();
    }

    private void InitializeDepthReprojection()
    {
        if (_isWebcamMode) return;

        // Find left/right eye anchors from the OVR camera rig hierarchy
        // Typical structure: TrackingSpace > LeftEyeAnchor / CenterEyeAnchor / RightEyeAnchor
        if (centerEyeAnchor != null && centerEyeAnchor.parent != null)
        {
            _leftEyeAnchor = centerEyeAnchor.parent.Find("LeftEyeAnchor");
            _rightEyeAnchor = centerEyeAnchor.parent.Find("RightEyeAnchor");
            if (_leftEyeAnchor != null && _rightEyeAnchor != null)
                Debug.Log("[OverlayRenderer] Found left/right eye anchors for depth reprojection");
            else
                Debug.LogWarning("[OverlayRenderer] Could not find eye anchors — depth reprojection will use center eye");
        }

        // Find or create EnvironmentDepthManager
        _depthManager = FindObjectOfType<EnvironmentDepthManager>();
        if (_depthManager == null)
        {
            if (EnvironmentDepthManager.IsSupported)
            {
                var depthObj = new GameObject("EnvironmentDepthManager");
                _depthManager = depthObj.AddComponent<EnvironmentDepthManager>();
                // We don't need occlusion shaders — just the depth texture
                _depthManager.OcclusionShadersMode = OcclusionShadersMode.None;
                _depthManager.RemoveHands = false;
                Debug.Log("[OverlayRenderer] Created EnvironmentDepthManager for depth reprojection");
            }
            else
            {
                Debug.LogWarning("[OverlayRenderer] Environment Depth not supported — using fixed right eye offset fallback");
            }
        }
    }

    private void CreateOverlaySphere()
    {
        // Main overlay sphere (outlines, dim, highlight, etc.)
        _sphereObj = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        _sphereObj.name = "OverlaySphere";

        var col = _sphereObj.GetComponent<Collider>();
        if (col != null) Destroy(col);

        _sphereObj.transform.localScale = Vector3.one * sphereRadius * 2f;
        _activeRenderer = _sphereObj.GetComponent<Renderer>();

        var shader = Shader.Find("SocialSense/SegmentOverlay");
        if (shader != null)
        {
            _material = new Material(shader);
            _activeRenderer.material = _material;
            Debug.Log("[OverlayRenderer] Created overlay sphere with SegmentOverlay shader");
        }
        else
        {
            Debug.LogError("[OverlayRenderer] Cannot find SocialSense/SegmentOverlay shader!");
        }

        // Blur sphere (real passthrough blur) - slightly smaller to render inside
        _blurSphereObj = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        _blurSphereObj.name = "BlurSphere";

        var blurCol = _blurSphereObj.GetComponent<Collider>();
        if (blurCol != null) Destroy(blurCol);

        // Blur sphere slightly larger - renders after overlay due to Queue=Overlay+10
        _blurSphereObj.transform.localScale = Vector3.one * sphereRadius * 2.02f;
        _blurRenderer = _blurSphereObj.GetComponent<Renderer>();

        // Load material from Resources to ensure shader is included in build
        // Shader.Find() doesn't work in builds because the shader gets stripped
        var blurMaterialAsset = Resources.Load<Material>("PassthroughBlurMaterial");
        if (blurMaterialAsset != null)
        {
            // Create instance so we can modify properties at runtime
            _blurMaterial = new Material(blurMaterialAsset);
            _blurRenderer.material = _blurMaterial;
            _blurSphereObj.SetActive(false);  // Start disabled
            Debug.Log("[OverlayRenderer] Created blur sphere with PassthroughBlur material from Resources");
        }
        else
        {
            // Fallback: try Shader.Find (works in Editor)
            var blurShader = Shader.Find("SocialSense/PassthroughBlur");
            if (blurShader != null)
            {
                _blurMaterial = new Material(blurShader);
                _blurRenderer.material = _blurMaterial;
                _blurSphereObj.SetActive(false);
                Debug.Log("[OverlayRenderer] Created blur sphere with PassthroughBlur shader (Shader.Find fallback)");
            }
            else
            {
                Debug.LogError("[OverlayRenderer] Cannot find PassthroughBlur material or shader - blur effects will NOT work!");
            }
        }

        // Initialize two-pass Gaussian blur materials
        InitBlurMaterials();
    }

    /// <summary>
    /// Initialize materials for the two-pass separable Gaussian blur.
    /// This is the correct way to do blur (like OpenCV) - horizontal pass then vertical pass.
    /// </summary>
    private void InitBlurMaterials()
    {
        // Load horizontal blur shader from Resources
        var hBlurShader = Resources.Load<Shader>("GaussianBlurHorizontal");
        if (hBlurShader != null)
        {
            _blurHorizontalMat = new Material(hBlurShader);
            Debug.Log("[OverlayRenderer] Loaded GaussianBlurHorizontal shader from Resources");
        }
        else
        {
            // Fallback: try Shader.Find (works in Editor)
            hBlurShader = Shader.Find("Hidden/SocialSense/GaussianBlurHorizontal");
            if (hBlurShader != null)
            {
                _blurHorizontalMat = new Material(hBlurShader);
                Debug.Log("[OverlayRenderer] Loaded GaussianBlurHorizontal via Shader.Find");
            }
            else
            {
                Debug.LogError("[OverlayRenderer] Cannot find GaussianBlurHorizontal shader!");
            }
        }

        // Load vertical blur shader from Resources
        var vBlurShader = Resources.Load<Shader>("GaussianBlurVertical");
        if (vBlurShader != null)
        {
            _blurVerticalMat = new Material(vBlurShader);
            Debug.Log("[OverlayRenderer] Loaded GaussianBlurVertical shader from Resources");
        }
        else
        {
            // Fallback: try Shader.Find (works in Editor)
            vBlurShader = Shader.Find("Hidden/SocialSense/GaussianBlurVertical");
            if (vBlurShader != null)
            {
                _blurVerticalMat = new Material(vBlurShader);
                Debug.Log("[OverlayRenderer] Loaded GaussianBlurVertical via Shader.Find");
            }
            else
            {
                Debug.LogError("[OverlayRenderer] Cannot find GaussianBlurVertical shader!");
            }
        }
    }

    /// <summary>
    /// Performs proper two-pass separable Gaussian blur on the source texture.
    /// Pass 1: Horizontal blur (samples left/right only)
    /// Pass 2: Vertical blur (samples up/down only)
    /// This is how OpenCV and all proper blur implementations work.
    /// </summary>
    private RenderTexture PerformTwoPassBlur(Texture source, float intensity)
    {
        if (source == null || _blurHorizontalMat == null || _blurVerticalMat == null)
            return null;

        int width = source.width;
        int height = source.height;

        // Create/resize render textures if needed
        if (_blurTempRT == null || _blurTempRT.width != width || _blurTempRT.height != height)
        {
            if (_blurTempRT != null) _blurTempRT.Release();
            if (_blurredPassthroughRT != null) _blurredPassthroughRT.Release();

            _blurTempRT = new RenderTexture(width, height, 0, RenderTextureFormat.ARGB32);
            _blurTempRT.wrapMode = TextureWrapMode.Clamp;
            _blurTempRT.filterMode = FilterMode.Bilinear;

            _blurredPassthroughRT = new RenderTexture(width, height, 0, RenderTextureFormat.ARGB32);
            _blurredPassthroughRT.wrapMode = TextureWrapMode.Clamp;
            _blurredPassthroughRT.filterMode = FilterMode.Bilinear;

            _blurRTWidth = width;
            _blurRTHeight = height;

            Debug.Log($"[OverlayRenderer] Created blur RenderTextures: {width}x{height}");
        }

        // Extreme privacy blur tuning:
        // intensity 0-1 maps to sigma 60-180, then clamped by shader radius.
        // This is intentionally aggressive so background details are not readable.
        // Increased from 45-140 to ensure sufficient blur strength.
        float sigma = 60f + intensity * 120f;

        // Set blur size on both materials
        _blurHorizontalMat.SetFloat(BlurSizeId, sigma);
        _blurVerticalMat.SetFloat(BlurSizeId, sigma);

        // Pass 1: Horizontal blur (source -> temp)
        Graphics.Blit(source, _blurTempRT, _blurHorizontalMat);

        // Pass 2: Vertical blur (temp -> final)
        Graphics.Blit(_blurTempRT, _blurredPassthroughRT, _blurVerticalMat);

        return _blurredPassthroughRT;
    }

    private float _debugLogTimer;

    void Update()
    {
        if (_material == null) return;

        // --- Calibration mode: right controller buttons adjust rightEyeOffset ---
        if (calibrationMode)
        {
            HandleCalibrationInput();
        }

        // Keep spheres centered on user's eye
        if (centerEyeAnchor != null)
        {
            if (_sphereObj != null)
                _sphereObj.transform.position = centerEyeAnchor.position;
            if (_blurSphereObj != null)
                _blurSphereObj.transform.position = centerEyeAnchor.position;
        }

        // Perform two-pass Gaussian blur on passthrough texture if blur is active.
        // Only applicable in AR mode (webcam mode uses overlay blur fallback).
        if (!_isWebcamMode && cameraAccess != null && cameraAccess.IsPlaying)
        {
            Texture passthrough = cameraAccess.GetTexture();
            if (passthrough != null)
            {
                // Check if we need blur (from current frame OR persistent inverted blur)
                // BUT if blur is fully disabled (after clear), don't blur
                bool needsBlur = !_blurFullyDisabled && (_hasBlurEffectThisFrame || _persistentInvertedBlur);
                float blurIntensity = _hasBlurEffectThisFrame ? _currentBlurIntensity : _persistentBlurIntensity;

                if (needsBlur && _blurHorizontalMat != null && _blurVerticalMat != null)
                {
                    // Perform two-pass separable Gaussian blur
                    RenderTexture blurredRT = PerformTwoPassBlur(passthrough, blurIntensity);
                    if (blurredRT != null && _blurMaterial != null)
                    {
                        _blurMaterial.SetTexture(PassthroughTexId, blurredRT);
                    }
                }
                else if (_blurMaterial != null)
                {
                    // No blur needed - pass through raw texture
                    _blurMaterial.SetTexture(PassthroughTexId, passthrough);
                }

                // Debug mode to verify passthrough texture is working
                if (_blurMaterial != null)
                    _blurMaterial.SetFloat(DebugRawPassthroughId, debugRawPassthrough ? 1f : 0f);
            }
        }

        // Note: EdgeFade is set in UpdateOverlay() to handle inverted effects properly
        // Don't set it here or it will override the inverted disable

        // In webcam mode or when intrinsics aren't available, use UV-based projection
        if (!_useIntrinsics || cameraAccess == null || !cameraAccess.IsPlaying)
        {
            _material.SetFloat(UseIntrinsicsId, 0.0f);
            if (_blurMaterial != null)
                _blurMaterial.SetFloat(UseIntrinsicsId, 0.0f);
            // Don't return early — webcam mode still needs Update to run for sphere positioning etc.
            // Only the intrinsics block below is skipped.
        }
        else
        {
        // --- Begin intrinsics block (AR mode only) ---

        try
        {
            var intrinsics = cameraAccess.Intrinsics;

            if (intrinsics.SensorResolution.x == 0 || intrinsics.SensorResolution.y == 0)
            {
                _material.SetFloat(UseIntrinsicsId, 0.0f);
                return;
            }

            // --- Camera rotation correction ---
            // LensOffset contains the physical camera's pose relative to the head.
            // Its rotation includes a 180° X flip (OpenCV → Unity convention) plus
            // any physical camera tilt. Extract the camera's projection axes in
            // head-local space so the pinhole model accounts for tilt.
            Pose lensOffset = intrinsics.LensOffset;
            Vector3 camForwardInHead = lensOffset.rotation * Vector3.forward;  // optical axis (+Z forward)
            Vector3 camUpInHead      = lensOffset.rotation * Vector3.up;     // camera "up" in Unity terms

            // Build head-local rotation that includes the camera's physical tilt.
            // With no tilt this reduces to identity, preserving current behavior.
            Quaternion cameraProjectionRot = Quaternion.LookRotation(camForwardInHead, camUpInHead);

            // Use capture-time head rotation if available (world-locked reprojection).
            // This makes masks stick to real-world positions instead of sliding
            // during head movement between capture and display.
            Quaternion headRotation = _hasCaptureRotation ? _captureRotation : centerEyeAnchor.rotation;

            _material.SetMatrix(CameraRotationMatrixId,
                Matrix4x4.Rotate(Quaternion.Inverse(headRotation * cameraProjectionRot)));

            _material.SetVector(FocalLengthId, intrinsics.FocalLength);

            // The camera texture (1280x960) is a center-crop of the full sensor
            // (1280x1280). The intrinsics are calibrated for the full sensor, so
            // we must adjust the principal point and use the actual image dimensions.
            Texture camTex = cameraAccess.GetTexture();
            float actualW = camTex != null ? camTex.width : intrinsics.SensorResolution.x;
            float actualH = camTex != null ? camTex.height : intrinsics.SensorResolution.y;
            float sensorW = intrinsics.SensorResolution.x;
            float sensorH = intrinsics.SensorResolution.y;

            // Compute crop offset (assumes center crop)
            float cropX = (sensorW - actualW) / 2f;
            float cropY = (sensorH - actualH) / 2f;

            // Adjust principal point from full-sensor coords to cropped-image coords
            float adjustedCx = intrinsics.PrincipalPoint.x - cropX;
            float adjustedCy = intrinsics.PrincipalPoint.y - cropY;

            // PP uses camera's native intrinsics, adjusted for center-crop only.
            // Both eyes project from the left camera position, so no per-eye PP needed.
            _material.SetVector(PrincipalPointId, new Vector2(adjustedCx, adjustedCy));

            // Cache intrinsics for label inverse projection
            _cachedFocalLength = intrinsics.FocalLength;
            _cachedPrincipalPoint = new Vector2(adjustedCx, adjustedCy);
            _cachedActualW = actualW;
            _cachedActualH = actualH;
            _cachedCameraProjectionRot = cameraProjectionRot;
            _intrinsicsValid = true;
            _material.SetVector(SensorResolutionId, new Vector4(actualW, actualH, 0, 0));
            _material.SetVector(ProjectionOffsetId,
                new Vector4(projectionOffset.x, projectionOffset.y, 0, 0));

            // Camera world position: both eyes project from the left camera
            // because the mask was captured by this camera. Stereo depth comes
            // from Unity's per-eye view-projection matrices, not from UV lookup.
            Vector3 camWorldPos = centerEyeAnchor.position
                + headRotation * lensOffset.position;

            _material.SetVector(CameraWorldPosId,
                new Vector4(camWorldPos.x, camWorldPos.y, camWorldPos.z, 0));
            _material.SetVector(RightEyeOffsetId,
                new Vector4(rightEyeOffset.x, rightEyeOffset.y, 0, 0));

            // Depth reprojection: pass per-eye world positions and enable flag
            _depthAvailable = _depthManager != null && _depthManager.IsDepthAvailable;
            _material.SetFloat(UseDepthReprojectionId, _depthAvailable ? 1.0f : 0.0f);
            if (_depthAvailable)
            {
                Vector3 leftEyePos = _leftEyeAnchor != null ? _leftEyeAnchor.position : centerEyeAnchor.position;
                Vector3 rightEyePos = _rightEyeAnchor != null ? _rightEyeAnchor.position : centerEyeAnchor.position;
                _material.SetVector(LeftEyeWorldPosId, new Vector4(leftEyePos.x, leftEyePos.y, leftEyePos.z, 0));
                _material.SetVector(RightEyeWorldPosId, new Vector4(rightEyePos.x, rightEyePos.y, rightEyePos.z, 0));
            }

            if (_overlayTexture != null && _texWidth > 0 && _texHeight > 0)
            {
                _material.SetVector(TextureResolutionId,
                    new Vector4(_texWidth, _texHeight, 0, 0));
                _material.SetFloat(UseIntrinsicsId, 1.0f);

                // Also set intrinsics on blur material so out-of-bounds works
                if (_blurMaterial != null)
                {
                    _blurMaterial.SetFloat(UseIntrinsicsId, 1.0f);
                    _blurMaterial.SetVector(FocalLengthId, _material.GetVector(FocalLengthId));
                    _blurMaterial.SetVector(PrincipalPointId, _material.GetVector(PrincipalPointId));
                    _blurMaterial.SetVector(SensorResolutionId, _material.GetVector(SensorResolutionId));
                    _blurMaterial.SetVector(TextureResolutionId, new Vector4(_texWidth, _texHeight, 0, 0));
                    _blurMaterial.SetMatrix(CameraRotationMatrixId, _material.GetMatrix(CameraRotationMatrixId));
                    _blurMaterial.SetVector(ProjectionOffsetId, _material.GetVector(ProjectionOffsetId));
                    _blurMaterial.SetVector(CameraWorldPosId, _material.GetVector(CameraWorldPosId));
                    _blurMaterial.SetVector(RightEyeOffsetId, _material.GetVector(RightEyeOffsetId));
                    _blurMaterial.SetFloat(UseDepthReprojectionId, _material.GetFloat(UseDepthReprojectionId));
                    _blurMaterial.SetVector(LeftEyeWorldPosId, _material.GetVector(LeftEyeWorldPosId));
                    _blurMaterial.SetVector(RightEyeWorldPosId, _material.GetVector(RightEyeWorldPosId));
                }
            }
            else
            {
                _material.SetFloat(UseIntrinsicsId, 0.0f);
                if (_blurMaterial != null)
                    _blurMaterial.SetFloat(UseIntrinsicsId, 0.0f);
            }

            if (Time.time - _debugLogTimer > 3f)
            {
                _debugLogTimer = Time.time;
                Vector3 lensEuler = lensOffset.rotation.eulerAngles;
                Debug.Log($"[OverlayRenderer] EyePos={centerEyeAnchor.position} " +
                          $"EyeFwd={centerEyeAnchor.forward:F3}");
                Debug.Log($"[OverlayRenderer] CamTex={actualW}x{actualH} " +
                          $"Sensor={sensorW}x{sensorH} " +
                          $"Crop=({cropX},{cropY}) " +
                          $"PP=({adjustedCx:F1},{adjustedCy:F1}) " +
                          $"Focal={intrinsics.FocalLength} " +
                          $"TexSize={_texWidth}x{_texHeight}");
                Debug.Log($"[OverlayRenderer] LensOffset pos=({lensOffset.position.x:F4},{lensOffset.position.y:F4},{lensOffset.position.z:F4}) " +
                          $"rot=({lensEuler.x:F1},{lensEuler.y:F1},{lensEuler.z:F1}) " +
                          $"camFwdLocal=({camForwardInHead.x:F3},{camForwardInHead.y:F3},{camForwardInHead.z:F3}) " +
                          $"camWorld=({camWorldPos.x:F4},{camWorldPos.y:F4},{camWorldPos.z:F4})");
                Debug.Log($"[OverlayRenderer] Depth: available={_depthAvailable} " +
                          $"manager={((_depthManager != null) ? "found" : "null")} " +
                          $"leftEye={(_leftEyeAnchor != null ? _leftEyeAnchor.position.ToString("F3") : "null")} " +
                          $"rightEye={(_rightEyeAnchor != null ? _rightEyeAnchor.position.ToString("F3") : "null")} " +
                          $"rightEyeOffset=({rightEyeOffset.x:F1},{rightEyeOffset.y:F1})");
            }
        }
        catch (Exception e)
        {
            if (Time.time - _debugLogTimer > 3f)
            {
                _debugLogTimer = Time.time;
                Debug.LogWarning($"[OverlayRenderer] Intrinsics failed: {e.Message}");
            }
            _material.SetFloat(UseIntrinsicsId, 0.0f);
        }
        } // --- End intrinsics block (AR mode only) ---
    }

    public void UpdateOverlay(Google.Protobuf.Collections.RepeatedField<SceneSegment> segments, Quaternion? captureRotation = null, bool effectsCleared = false)
    {
        if (captureRotation.HasValue)
        {
            _captureRotation = captureRotation.Value;
            _hasCaptureRotation = true;
        }

        // If server explicitly says effects were cleared, reset persistent blur
        if (effectsCleared)
        {
            Debug.Log("[OverlayRenderer] Server sent effectsCleared=true, clearing all persistent effects");
            ClearOverlay();
            HideAllLabels();
            return;
        }

        if (_activeRenderer == null || segments == null || segments.Count == 0)
        {
            // Empty segments - keep persistent blur if active (target just not detected)
            // But clear other visual overlays
            if (_persistentInvertedBlur)
            {
                ClearVisualOverlays();
                UpdateBlurSphere();
            }
            else
            {
                ClearOverlay();
            }
            HideAllLabels();
            return;
        }

        int maskW = (int)segments[0].MaskWidth;
        int maskH = (int)segments[0].MaskHeight;
        if (maskW == 0 || maskH == 0)
        {
            if (_persistentInvertedBlur)
            {
                ClearVisualOverlays();
                UpdateBlurSphere();
            }
            else
            {
                ClearOverlay();
            }
            HideAllLabels();
            return;
        }

        EnsureTexture(maskW, maskH);

        Array.Fill(_pixelBuffer, ClearPixel);
        Array.Fill(_blurMaskBuffer, ClearPixel);

        // Track which segments have active effects this frame (for cleanup)
        var activeEffectIds = new HashSet<string>();
        _hasInvertedEffectThisFrame = false;
        _currentInvertedEffectColor = Color.clear;
        _hasBlurEffectThisFrame = false;
        _currentBlurIntensity = 0f;
        _isBlurInverted = false;

        int segIndex = 0;
        foreach (var seg in segments)
        {
            Color32 color = BrightColors[segIndex % BrightColors.Length];
            string effectType = seg.Effect?.EffectType ?? "none";
            float rawIntensity = seg.Effect?.Intensity ?? 0f;
            string colorHex = seg.Effect?.ColorHex ?? null;
            bool hasEffect = effectType != "none" && effectType != "";
            // Default intensity when server sends 0 (protobuf default for unset float)
            float intensity = (hasEffect && rawIntensity <= 0f) ? 0.7f : rawIntensity;
            bool invert = seg.Effect?.Invert ?? false;

            // Debug: log what effect metadata the server sent for each segment
            if (Time.time - _debugLogTimer > 2f)
            {
                Debug.Log($"[OverlayRenderer] Seg[{segIndex}] label='{seg.Label}' asset='{seg.AssetClass}' " +
                          $"effectType='{effectType}' rawIntensity={rawIntensity:F2} colorHex='{colorHex}' " +
                          $"hasEffect={hasEffect} invert={invert}");
            }

            // Check if mask is empty/missing
            bool hasMask = seg.RleMask != null && !seg.RleMask.IsEmpty &&
                           seg.MaskWidth == maskW && seg.MaskHeight == maskH;

            // Track if we're using full-screen fallback (inverted effect with no target detected)
            bool fullScreenFallback = false;

            // For inverted effects with no mask (target not detected):
            // Apply effect to EVERYTHING (since "blur everything except X" when X not found = blur everything)
            if (hasEffect && invert && !hasMask)
            {
                // Fill entire mask as fully opaque (effect applies everywhere)
                Array.Fill(_maskTemp, (byte)255);
                fullScreenFallback = true;  // Don't invert later - already set to full screen
            }
            else if (!hasMask)
            {
                // No mask and not an inverted effect - skip
                segIndex++;
                continue;
            }
            else
            {
                // Normal case: decode the mask
                DecodeRleIntoMask(seg.RleMask.ToByteArray(), maskW, maskH);
                SmoothMask(maskW, maskH);
            }

            if (hasEffect)
            {
                // Track animation start time per segment
                // For inverted effects, use just effect type as key since it covers whole screen
                // This prevents animation restart when track ID changes
                string trackKey = seg.TrackId.Length > 0 ? seg.TrackId : $"seg_{segIndex}";
                string effectKey = invert
                    ? $"__inverted__:{effectType}"  // Stable key for inverted effects
                    : $"{trackKey}:{effectType}";
                activeEffectIds.Add(effectKey);

                if (!_effectStartTimes.ContainsKey(effectKey))
                    _effectStartTimes[effectKey] = Time.time;

                float elapsed = Time.time - _effectStartTimes[effectKey];
                float animProgress = Mathf.Clamp01(elapsed / EFFECT_FADE_DURATION);

                // Track blur effects for real passthrough blur
                if (effectType == "blur")
                {
                    if (!ShouldUseOverlayBlurFallback())
                    {
                        // Re-enable blur processing (was disabled by ClearOverlay)
                        _blurFullyDisabled = false;

                        _hasBlurEffectThisFrame = true;
                        _currentBlurIntensity = Mathf.Max(_currentBlurIntensity, intensity);

                        // CRITICAL: Reset persistent inverted state when we get a NEW blur command
                        // This ensures "blur X" after "blur everything but Y" doesn't inherit inverted mode
                        if (invert)
                        {
                            _isBlurInverted = true;
                            _persistentInvertedBlur = true;
                            _persistentBlurIntensity = intensity;
                        }
                        else
                        {
                            // Non-inverted blur: explicitly clear inverted state
                            _isBlurInverted = false;
                            _persistentInvertedBlur = false;
                            _persistentBlurIntensity = 0f;
                        }
                    }
                    else
                    {
                        // Editor fallback path: keep blur sphere disabled and render blur as overlay.
                        _hasBlurEffectThisFrame = false;
                        _currentBlurIntensity = 0f;
                        _isBlurInverted = false;
                        _persistentInvertedBlur = false;
                        _persistentBlurIntensity = 0f;
                    }
                }

                // Invert: flip mask so effect applies to everything OUTSIDE the segment
                // Skip invert if we already did full-screen fallback (target not detected)
                if (invert)
                {
                    _hasInvertedEffectThisFrame = true;
                    if (!fullScreenFallback)
                        InvertMask(maskW, maskH);

                    // Get effect color and apply animation progress to alpha
                    // This makes border and inside animate together
                    Color32 effectColor32;
                    if (effectType == "blur")
                    {
                        // Neutral gray for blur out-of-bounds - blends with blurred passthrough
                        // Use lower alpha so it's subtle and blends with edge fade
                        effectColor32 = new Color32(128, 128, 130, (byte)(180 * intensity * animProgress));
                    }
                    else
                    {
                        effectColor32 = GetEffectColor(effectType, intensity, color, colorHex);
                        // Apply animation progress to alpha so border fades in with effect
                        effectColor32.a = (byte)(effectColor32.a * animProgress);
                    }
                    _currentInvertedEffectColor = new Color(
                        effectColor32.r / 255f, effectColor32.g / 255f,
                        effectColor32.b / 255f, effectColor32.a / 255f);
                }

                if (invert)
                {
                    // Inverted effects: animate from edges inward
                    // For blur, use full intensity (blur mask needs full alpha to show blur)
                    // For other effects, apply animation progress
                    float effectIntensity = (effectType == "blur") ? intensity : intensity * animProgress;
                    RenderEffect(maskW, maskH, effectType, effectIntensity, color, colorHex);
                }
                else
                {
                    // Non-inverted: effect fades in (alpha ramp)
                    // For blur, use full intensity immediately
                    float effectIntensity = (effectType == "blur") ? intensity : intensity * animProgress;
                    RenderEffect(maskW, maskH, effectType, effectIntensity, color, colorHex);
                }
            }
            else if (outlineMode)
            {
                // Default: outline mode
                color.a = 255;
                DrawOutlineFromMask(maskW, maskH, color);
            }
            else
            {
                // Default: filled mode
                Color32 fillColor = GetColor(seg.AssetClass, (byte)segmentAlpha);
                ApplyMaskToBuffer(maskW, maskH, fillColor);
            }

            segIndex++;
        }

        // Purge start times for effects that are no longer active
        var staleKeys = new List<string>();
        foreach (var key in _effectStartTimes.Keys)
            if (!activeEffectIds.Contains(key)) staleKeys.Add(key);
        foreach (var key in staleKeys)
            _effectStartTimes.Remove(key);

        // Check if any segment was actually processed (had a mask or was a fullscreen fallback)
        // If we processed segments but found no blur effects, that means "clear" was called
        // If segments were empty (returned early above), we keep persistent blur
        bool processedAnySegment = segIndex > 0;
        if (processedAnySegment && !_hasBlurEffectThisFrame)
        {
            // We saw segments but none had blur - this is a "clear" command
            _persistentInvertedBlur = false;
            _persistentBlurIntensity = 0f;
        }

        _overlayTexture.SetPixels32(_pixelBuffer);
        _overlayTexture.Apply(false);

        // Upload blur mask texture if we have blur effects
        if (_hasBlurEffectThisFrame && _blurMaskTexture != null)
        {
            // Count non-zero pixels in blur mask for debugging
            int nonZeroCount = 0;
            for (int i = 0; i < _blurMaskBuffer.Length; i++)
            {
                if (_blurMaskBuffer[i].a > 0)
                    nonZeroCount++;
            }

            if (Time.time - _blurDebugTimer > 2f)
            {
                Debug.Log($"[BlurMask] Writing {nonZeroCount}/{_blurMaskBuffer.Length} non-zero pixels " +
                          $"({100f * nonZeroCount / _blurMaskBuffer.Length:F1}%) " +
                          $"intensity={_currentBlurIntensity:F2} inverted={_isBlurInverted}");
            }

            _blurMaskTexture.SetPixels32(_blurMaskBuffer);
            _blurMaskTexture.Apply(false);
        }

        if (_material != null)
        {
            _material.mainTexture = _overlayTexture;
            _material.SetFloat(GlobalAlphaId, globalAlpha);

            // Disable edge fade when inverted effects are active so blur/dim reaches screen edges
            float effectiveEdgeFade = (_hasInvertedEffectThisFrame && disableEdgeFadeForInvertedEffects) ? 0f : edgeFade;
            _material.SetFloat(EdgeFadeId, effectiveEdgeFade);

            // Set out-of-bounds color for inverted effects (fills edges of headset beyond camera FOV)
            _material.SetColor(OutOfBoundsColorId, _currentInvertedEffectColor);

            // Debug logging for out-of-bounds
            if (_hasInvertedEffectThisFrame && Time.time - _blurDebugTimer > 2f)
            {
                Debug.Log($"[OutOfBounds] inverted={_hasInvertedEffectThisFrame} " +
                          $"color=({_currentInvertedEffectColor.r:F2},{_currentInvertedEffectColor.g:F2},{_currentInvertedEffectColor.b:F2},{_currentInvertedEffectColor.a:F2}) " +
                          $"isBlurInverted={_isBlurInverted}");
            }
        }

        // Webcam mode: set overlay texture on the flat quad (aligned with webcam feed)
        if (_isWebcamMode && _webcamOverlayMaterial != null)
        {
            _webcamOverlayMaterial.mainTexture = _overlayTexture;
            if (_webcamOverlayQuad != null) _webcamOverlayQuad.SetActive(true);
            UpdateWebcamOverlayQuadSize();
        }

        // Update blur sphere for real passthrough blur effect
        UpdateBlurSphere();

        if (showLabels)
            UpdateLabels(segments);
        else
            HideAllLabels();
    }

    private float _blurDebugTimer;

    /// <summary>
    /// Enables/disables the blur sphere and sets blur parameters.
    /// The blur sphere samples the actual passthrough camera texture and applies
    /// a Gaussian blur, creating a real frosted glass effect instead of a solid overlay.
    /// </summary>
    private void UpdateBlurSphere()
    {
        if (_blurSphereObj == null || _blurMaterial == null)
        {
            // Log when blur is expected but material is missing
            if (_hasBlurEffectThisFrame && Time.time - _blurDebugTimer > 2f)
            {
                _blurDebugTimer = Time.time;
                Debug.LogWarning($"[BlurSphere] MISSING! sphere={(_blurSphereObj != null)} material={(_blurMaterial != null)} - shader not included in build?");
            }
            return;
        }

        // Activate blur sphere if:
        // 1. Blur effect is active this frame, OR
        // 2. Persistent inverted blur is active (keeps blur when target not detected), OR
        // 3. Debug mode is on
        // BUT NOT if blur is fully disabled (after clear command)
        bool blurActive = !_blurFullyDisabled && ((_hasBlurEffectThisFrame && _currentBlurIntensity > 0f) || _persistentInvertedBlur);

        if (blurActive || debugRawPassthrough)
        {
            _blurSphereObj.SetActive(true);

            // Use current intensity if available, otherwise use persistent intensity
            float effectiveIntensity = _hasBlurEffectThisFrame ? _currentBlurIntensity : _persistentBlurIntensity;

            // Note: blur size is no longer used in the sphere shader since we pre-blur
            // But keep for debug logging
            float blurSize = 30f + effectiveIntensity * 90f;
            _blurMaterial.SetFloat(GlobalAlphaId, globalAlpha);

            // For inverted blur (blur everything except X), fill edges beyond camera FOV
            // Use full alpha so edges of headset are fully blurred
            bool isInverted = _isBlurInverted || _persistentInvertedBlur;
            float outOfBoundsAlpha = isInverted ? 1.0f : 0f;
            _blurMaterial.SetFloat(OutOfBoundsAlphaId, outOfBoundsAlpha);

            // Set debug mode for blur shader (0=off, 1=mask, 2=passthrough with flip, 3=passthrough no flip)
            _blurMaterial.SetFloat(BlurDebugModeId, (float)blurDebugMode);

            // Debug logging
            if (Time.time - _blurDebugTimer > 2f)
            {
                _blurDebugTimer = Time.time;
                Texture pt = cameraAccess?.GetTexture();
                float useIntrinsics = _blurMaterial.GetFloat(UseIntrinsicsId);
                Debug.Log($"[BlurSphere] ACTIVE intensity={_currentBlurIntensity:F2} inverted={_isBlurInverted} " +
                          $"outOfBoundsAlpha={outOfBoundsAlpha} blurSize={blurSize} " +
                          $"useIntrinsics={useIntrinsics} debugRaw={debugRawPassthrough} " +
                          $"passthrough={(pt != null ? $"{pt.width}x{pt.height}" : "NULL")} " +
                          $"blurMask={(_blurMaskTexture != null ? $"{_texWidth}x{_texHeight}" : "NULL")}");
            }

            // Pass the blur mask texture to the blur shader
            if (_blurMaskTexture != null)
            {
                _blurMaterial.mainTexture = _blurMaskTexture;
                _blurMaterial.SetVector(TextureResolutionId, new Vector4(_texWidth, _texHeight, 0, 0));
            }

            // Copy camera intrinsics from main material to blur material
            // so the blur shader can project correctly
            if (_material != null && _useIntrinsics)
            {
                _blurMaterial.SetFloat(UseIntrinsicsId, _material.GetFloat(UseIntrinsicsId));
                _blurMaterial.SetVector(FocalLengthId, _material.GetVector(FocalLengthId));
                _blurMaterial.SetVector(PrincipalPointId, _material.GetVector(PrincipalPointId));
                _blurMaterial.SetVector(SensorResolutionId, _material.GetVector(SensorResolutionId));
                _blurMaterial.SetMatrix(CameraRotationMatrixId, _material.GetMatrix(CameraRotationMatrixId));
                _blurMaterial.SetVector(ProjectionOffsetId, _material.GetVector(ProjectionOffsetId));
                _blurMaterial.SetVector(CameraWorldPosId, _material.GetVector(CameraWorldPosId));
                _blurMaterial.SetVector(RightEyeOffsetId, _material.GetVector(RightEyeOffsetId));
                _blurMaterial.SetFloat(UseDepthReprojectionId, _material.GetFloat(UseDepthReprojectionId));
                _blurMaterial.SetVector(LeftEyeWorldPosId, _material.GetVector(LeftEyeWorldPosId));
                _blurMaterial.SetVector(RightEyeWorldPosId, _material.GetVector(RightEyeWorldPosId));
            }
            else
            {
                _blurMaterial.SetFloat(UseIntrinsicsId, 0f);
            }
        }
        else
        {
            _blurSphereObj.SetActive(false);
        }
    }


    private void RenderEffect(int w, int h, string effectType, float intensity, Color32 segColor, string colorHex = null)
    {
        switch (effectType)
        {
            case "blur":
                if (ShouldUseOverlayBlurFallback())
                {
                    // Webcam mode: GPU blur the webcam texture, then write blurred pixels
                    // into the overlay buffer where the mask is true.
                    ApplyWebcamBlurToBuffer(w, h, intensity);
                }
                else
                {
                    // Real blur uses PassthroughBlur shader on blur sphere
                    // Write mask to blur buffer so shader knows WHERE to blur
                    // Always write the mask, even if blur material is missing
                    // Increased alpha from 190-255 to 240-255 for stronger blur visibility
                    byte blurMaskAlpha = (byte)Mathf.Clamp(240f + 15f * intensity, 0f, 255f);
                    ApplyMaskToBlurBuffer(w, h, new Color32(255, 255, 255, blurMaskAlpha));
                }
                break;

            case "color":
                // Color overlay effect — intensity directly controls opacity
                Color32? parsedColor = ColorUtility.ParseColorHex(colorHex);
                Color32 overlayColor = parsedColor ?? segColor;  // Fallback to segment color

                // If hex included explicit alpha (8-char), use it directly.
                // Otherwise, intensity controls opacity: 0.0 = transparent, 1.0 = opaque.
                if (colorHex != null && colorHex.TrimStart('#').Length == 8)
                {
                    // Explicit alpha from hex — scale by intensity
                    overlayColor.a = (byte)(overlayColor.a * intensity);
                }
                else
                {
                    // Intensity = opacity. Scale from 0 to 255.
                    overlayColor.a = (byte)(255f * intensity);
                }
                ApplyMaskToBuffer(w, h, overlayColor);
                break;

            case "dim":
                // Semi-transparent black overlay for dimming/darkening effect.
                // Alpha raised: at intensity 1.0, dim should be very strong (nearly opaque).
                // Minimum alpha of 60 so even low-intensity dim is clearly visible.
                byte dimAlpha = (byte)Mathf.Clamp(60f + 195f * intensity, 0f, 255f);
                ApplyMaskToBuffer(w, h, new Color32(0, 0, 0, dimAlpha));
                break;

            case "pixelate":
                // Solid block pattern to simulate heavy pixelation/censoring
                // Uses larger blocks with high-contrast colors for visibility
                int blockSize = Math.Max(8, (int)(32 * intensity));
                ApplyBlockPatternToBuffer(w, h, blockSize);
                break;

            case "highlight":
                // Semi-transparent warm bright overlay.
                // Raised opacity: at intensity 1.0, highlight should be clearly visible.
                byte hlAlpha = (byte)Mathf.Clamp(80f + 175f * intensity, 0f, 255f);
                ApplyMaskToBuffer(w, h, new Color32(255, 255, 180, hlAlpha));
                break;

            case "outline":
                // Thick colored outline with intensity-scaled width
                int thickness = Math.Max(3, (int)(8 * intensity));
                DrawOutlineFromMask(w, h, segColor, thickness);
                break;

            // --- Custom mask types (voice-parsable, additive) ---

            case "frosted_glass":
                // Frosted glass: semi-transparent white overlay with slight transparency
                // On Quest, real blur is applied via the blur sphere; this is the overlay tint.
                byte frostAlpha = (byte)Mathf.Clamp(140f + 80f * intensity, 0f, 255f);
                ApplyMaskToBuffer(w, h, new Color32(230, 235, 245, frostAlpha));
                // Also write to blur buffer for the actual frosted glass blur
                byte frostBlurAlpha = (byte)Mathf.Clamp(200f + 55f * intensity, 0f, 255f);
                ApplyMaskToBlurBuffer(w, h, new Color32(255, 255, 255, frostBlurAlpha));
                break;

            case "redact":
                // Redaction bar: solid black rectangle over the mask area
                ApplyMaskToBuffer(w, h, new Color32(0, 0, 0, 255));
                break;

            case "grayscale":
                // Grayscale: neutral gray overlay (actual grayscale conversion happens in shader)
                byte grayAlpha = (byte)Mathf.Clamp(180f + 75f * intensity, 0f, 255f);
                ApplyMaskToBuffer(w, h, new Color32(128, 128, 128, grayAlpha));
                break;

            case "desaturate":
                // Desaturate: muted gray overlay to reduce color saturation
                byte desatAlpha = (byte)Mathf.Clamp(100f + 120f * intensity, 0f, 255f);
                ApplyMaskToBuffer(w, h, new Color32(160, 160, 160, desatAlpha));
                break;

            case "noise":
                // Noise/static: randomized block pattern for obfuscation
                int noiseBlockSize = Math.Max(4, (int)(16 * intensity));
                ApplyBlockPatternToBuffer(w, h, noiseBlockSize);
                break;

            case "soft_glow":
                // Soft glow: warm yellowish semi-transparent overlay
                byte glowAlpha = (byte)Mathf.Clamp(60f + 120f * intensity, 0f, 255f);
                ApplyMaskToBuffer(w, h, new Color32(255, 245, 200, glowAlpha));
                break;

            case "warm_tint":
                // Warm tint overlay
                byte warmAlpha = (byte)Mathf.Clamp(80f + 140f * intensity, 0f, 255f);
                ApplyMaskToBuffer(w, h, new Color32(255, 200, 150, warmAlpha));
                break;

            case "cool_tint":
                // Cool tint overlay
                byte coolAlpha = (byte)Mathf.Clamp(80f + 140f * intensity, 0f, 255f);
                ApplyMaskToBuffer(w, h, new Color32(150, 200, 255, coolAlpha));
                break;

            case "reduce_contrast":
                // Reduce contrast: neutral mid-gray semi-transparent overlay
                byte rcAlpha = (byte)Mathf.Clamp(60f + 100f * intensity, 0f, 255f);
                ApplyMaskToBuffer(w, h, new Color32(140, 140, 140, rcAlpha));
                break;
        }
    }

    /// <summary>
    /// Renders an inverted effect that sweeps in from frame edges.
    /// At progress=0 nothing visible. At progress=1 fully applied.
    /// The sweep front moves from edges toward the segment boundary.
    /// </summary>
    private void RenderEffectWithEdgeSweep(int w, int h, string effectType, float intensity, Color32 segColor, float progress, string colorHex = null)
    {
        if (progress <= 0f) return;

        // At full progress, just render normally
        if (progress >= 1f)
        {
            RenderEffect(w, h, effectType, intensity, segColor, colorHex);
            return;
        }

        // For blur with real shader, write to blur mask buffer instead
        bool isRealBlur = (effectType == "blur" && _blurMaterial != null);

        // For each masked pixel, compute normalized distance from nearest frame edge.
        // 0 = at edge, 0.5 = at center. The sweep front is at progress * 0.5.
        float halfW = w * 0.5f;
        float halfH = h * 0.5f;
        float maxDist = Mathf.Min(halfW, halfH);
        float sweepFront = progress * maxDist;

        // Get the effect color for this type
        Color32 effectColor = GetEffectColor(effectType, intensity, segColor, colorHex);

        for (int y = 0; y < h; y++)
        {
            // Distance from nearest horizontal edge
            float edgeDistY = Mathf.Min(y, h - 1 - y);

            for (int x = 0; x < w; x++)
            {
                int idx = y * w + x;
                byte maskAlpha = _maskTemp[idx];
                if (maskAlpha == 0) continue;

                // Distance from nearest edge (min of all 4 sides)
                float edgeDistX = Mathf.Min(x, w - 1 - x);
                float edgeDist = Mathf.Min(edgeDistX, edgeDistY);

                if (edgeDist > sweepFront) continue;

                // Soft edge: fade near the sweep front
                float softZone = Mathf.Max(8f, sweepFront * 0.15f);
                float alpha01 = edgeDist > (sweepFront - softZone)
                    ? 1f - (edgeDist - (sweepFront - softZone)) / softZone
                    : 1f;

                Color32 pixel = effectColor;
                // Combine sweep alpha with mask edge alpha
                pixel.a = (byte)(pixel.a * alpha01 * maskAlpha / 255f);

                if (pixel.a > 0)
                {
                    if (isRealBlur)
                        _blurMaskBuffer[idx] = pixel;
                    else
                        _pixelBuffer[idx] = pixel;
                }
            }
        }
    }

    private Color32 GetEffectColor(string effectType, float intensity, Color32 segColor, string colorHex = null)
    {
        switch (effectType)
        {
            case "blur":
                // For border: frosted gray - alpha must match blur mask (255 * intensity)
                return new Color32(140, 140, 150, (byte)(255 * intensity));
            case "color":
                Color32? parsedColor = ColorUtility.ParseColorHex(colorHex);
                Color32 overlayColor = parsedColor ?? segColor;
                overlayColor.a = (byte)(255 * intensity);
                return overlayColor;
            case "dim":
                return new Color32(0, 0, 0, (byte)(200 * intensity));
            case "highlight":
                return new Color32(255, 255, 180, (byte)(76 * intensity));
            case "outline":
                segColor.a = 255;
                return segColor;
            case "pixelate":
                return new Color32(70, 70, 80, 230);
            default:
                return new Color32(0, 0, 0, 0);
        }
    }

    private void ApplyMaskToBuffer(int w, int h, Color32 color)
    {
        int total = w * h;
        for (int i = 0; i < total; i++)
        {
            byte maskAlpha = _maskTemp[i];
            if (maskAlpha == 0) continue;
            if (maskAlpha == 255)
            {
                _pixelBuffer[i] = color;
            }
            else
            {
                _pixelBuffer[i] = new Color32(color.r, color.g, color.b,
                    (byte)((color.a * maskAlpha + 127) / 255));
            }
        }
    }

    private void ApplyMaskToBlurBuffer(int w, int h, Color32 color)
    {
        int total = w * h;
        for (int i = 0; i < total; i++)
        {
            byte maskAlpha = _maskTemp[i];
            if (maskAlpha == 0) continue;
            if (maskAlpha == 255)
            {
                _blurMaskBuffer[i] = color;
            }
            else
            {
                _blurMaskBuffer[i] = new Color32(color.r, color.g, color.b,
                    (byte)((color.a * maskAlpha + 127) / 255));
            }
        }
    }

    /// <summary>
    /// GPU-blurs the webcam texture and writes the blurred pixels into _pixelBuffer
    /// wherever the mask is true. Uses the same two-pass Gaussian blur pipeline as AR mode.
    /// </summary>
    private void ApplyWebcamBlurToBuffer(int w, int h, float intensity)
    {
        if (webcamSourceTexture == null || _blurHorizontalMat == null || _blurVerticalMat == null)
        {
            // Fallback: frosted overlay if blur pipeline unavailable
            byte frostAlpha = (byte)Mathf.Clamp(200f + 55f * intensity, 0f, 255f);
            ApplyMaskToBuffer(w, h, new Color32(220, 225, 235, frostAlpha));
            return;
        }

        // GPU two-pass Gaussian blur on the webcam texture
        RenderTexture blurredRT = PerformTwoPassBlur(webcamSourceTexture, intensity);
        if (blurredRT == null)
        {
            byte frostAlpha = (byte)Mathf.Clamp(200f + 55f * intensity, 0f, 255f);
            ApplyMaskToBuffer(w, h, new Color32(220, 225, 235, frostAlpha));
            return;
        }

        // Read back blurred pixels to CPU
        int bw = blurredRT.width;
        int bh = blurredRT.height;
        if (_blurredWebcamReadback == null || _blurredWebcamReadback.width != bw || _blurredWebcamReadback.height != bh)
        {
            _blurredWebcamReadback = new Texture2D(bw, bh, TextureFormat.RGBA32, false);
        }

        RenderTexture prev = RenderTexture.active;
        RenderTexture.active = blurredRT;
        _blurredWebcamReadback.ReadPixels(new Rect(0, 0, bw, bh), 0, 0, false);
        _blurredWebcamReadback.Apply(false);
        RenderTexture.active = prev;

        _blurredWebcamPixels = _blurredWebcamReadback.GetPixels32();

        // Write blurred pixels into overlay buffer where mask is active
        // Mask resolution (w x h) may differ from webcam resolution (bw x bh), so we map
        int total = w * h;
        for (int i = 0; i < total; i++)
        {
            byte maskAlpha = _maskTemp[i];
            if (maskAlpha == 0) continue;

            // Map mask pixel to blurred webcam pixel
            int mx = i % w;
            int my = i / w;
            int bx = mx * bw / w;
            int by = my * bh / h;
            int bi = by * bw + bx;

            if (bi >= 0 && bi < _blurredWebcamPixels.Length)
            {
                Color32 blurred = _blurredWebcamPixels[bi];
                blurred.a = maskAlpha; // Use smooth mask alpha for soft edges
                _pixelBuffer[i] = blurred;
            }
        }
    }

    private void ApplyCheckerboardToBuffer(int w, int h, int blockSize, Color32 color)
    {
        color.a = 180;
        Color32 altColor = new Color32(
            (byte)(color.r / 2), (byte)(color.g / 2), (byte)(color.b / 2), 160);

        for (int y = 0; y < h; y++)
        {
            for (int x = 0; x < w; x++)
            {
                int idx = y * w + x;
                byte maskAlpha = _maskTemp[idx];
                if (maskAlpha == 0) continue;

                bool checker = ((x / blockSize) + (y / blockSize)) % 2 == 0;
                Color32 pixel = checker ? color : altColor;
                if (maskAlpha < 255)
                    pixel.a = (byte)((pixel.a * maskAlpha + 127) / 255);
                _pixelBuffer[idx] = pixel;
            }
        }
    }

    private void ApplyBlockPatternToBuffer(int w, int h, int blockSize)
    {
        // High-contrast block pattern that looks like heavy pixelation/mosaic censoring
        Color32[] blockColors = new Color32[]
        {
            new Color32(40, 40, 50, 230),
            new Color32(80, 80, 90, 230),
            new Color32(60, 60, 70, 230),
            new Color32(100, 100, 110, 230),
        };

        for (int y = 0; y < h; y++)
        {
            int blockY = y / blockSize;
            for (int x = 0; x < w; x++)
            {
                int idx = y * w + x;
                byte maskAlpha = _maskTemp[idx];
                if (maskAlpha == 0) continue;

                int blockX = x / blockSize;
                // Use a pseudo-random but stable color per block
                int colorIdx = ((blockX * 7) + (blockY * 13)) % blockColors.Length;
                Color32 pixel = blockColors[colorIdx];
                if (maskAlpha < 255)
                    pixel.a = (byte)((pixel.a * maskAlpha + 127) / 255);
                _pixelBuffer[idx] = pixel;
            }
        }
    }

    /// <summary>
    /// Smooths a binary mask using:
    /// 1. Binary median filter (3x3 majority vote) to remove noisy specks
    /// 2. Separable box blur to create soft edge gradients
    /// 3. Smoothstep remap to snap interior/exterior back to solid while keeping edges smooth
    /// </summary>
    private void SmoothMask(int w, int h)
    {
        if (maskSmoothRadius <= 0) return;

        int radius = maskSmoothRadius;
        int total = w * h;

        // Pre-pass: 3x3 binary median filter to remove isolated specks and noise.
        // For binary data (0/255), median = majority vote: pixel is 255 if 5+ of 9 neighbors are 255.
        // This kills isolated pixels and tiny clusters that cause flickering at mask boundaries.
        for (int y = 0; y < h; y++)
        {
            for (int x = 0; x < w; x++)
            {
                int count = 0;
                for (int dy = -1; dy <= 1; dy++)
                {
                    int ny = y + dy;
                    if (ny < 0 || ny >= h) continue;
                    int rowOff = ny * w;
                    for (int dx = -1; dx <= 1; dx++)
                    {
                        int nx = x + dx;
                        if (nx < 0 || nx >= w) continue;
                        if (_maskTemp[rowOff + nx] >= 128) count++;
                    }
                }
                // Majority vote: 5 out of 9 (or proportional at edges)
                _maskSmooth[y * w + x] = count >= 5 ? (byte)255 : (byte)0;
            }
        }
        // Copy cleaned result back
        Array.Copy(_maskSmooth, _maskTemp, total);

        // Pass 1: Horizontal blur (_maskTemp -> _maskSmooth) using sliding window
        for (int y = 0; y < h; y++)
        {
            int rowStart = y * w;
            int sum = 0;
            int count = 0;

            // Initialize window for x=0
            for (int dx = 0; dx <= radius && dx < w; dx++)
            {
                sum += _maskTemp[rowStart + dx];
                count++;
            }

            for (int x = 0; x < w; x++)
            {
                _maskSmooth[rowStart + x] = (byte)(sum / count);

                // Slide window: remove leftmost, add new rightmost
                int removeX = x - radius;
                int addX = x + radius + 1;
                if (removeX >= 0) { sum -= _maskTemp[rowStart + removeX]; count--; }
                if (addX < w) { sum += _maskTemp[rowStart + addX]; count++; }
            }
        }

        // Pass 2: Vertical blur (_maskSmooth -> _maskTemp) using sliding window
        for (int x = 0; x < w; x++)
        {
            int sum = 0;
            int count = 0;

            // Initialize window for y=0
            for (int dy = 0; dy <= radius && dy < h; dy++)
            {
                sum += _maskSmooth[dy * w + x];
                count++;
            }

            for (int y = 0; y < h; y++)
            {
                _maskTemp[y * w + x] = (byte)(sum / count);

                // Slide window
                int removeY = y - radius;
                int addY = y + radius + 1;
                if (removeY >= 0) { sum -= _maskSmooth[removeY * w + x]; count--; }
                if (addY < h) { sum += _maskSmooth[addY * w + x]; count++; }
            }
        }

        // Pass 3: Smoothstep remap to preserve fine features
        // Maps: 0-64 -> near 0, 64-192 -> smooth S-curve, 192-255 -> near 255
        for (int i = 0; i < total; i++)
        {
            float t = _maskTemp[i] / 255f;
            // smoothstep(0.25, 0.75, t): remaps 64/255≈0.25 to 0, 192/255≈0.75 to 1
            t = Mathf.Clamp01((t - 0.25f) / 0.5f);
            t = t * t * (3f - 2f * t); // smoothstep polynomial
            _maskTemp[i] = (byte)(t * 255f + 0.5f);
        }
    }

    private void InvertMask(int w, int h)
    {
        int total = w * h;
        for (int i = 0; i < total; i++)
            _maskTemp[i] = (byte)(255 - _maskTemp[i]);
    }

    /// <summary>
    /// Clears visual overlays (outlines, labels, etc.) but keeps blur going if persistent.
    /// Called when segments are empty but we still want blur to continue.
    /// </summary>
    private void ClearVisualOverlays()
    {
        if (_overlayTexture != null && _pixelBuffer != null)
        {
            Array.Fill(_pixelBuffer, ClearPixel);
            _overlayTexture.SetPixels32(_pixelBuffer);
            _overlayTexture.Apply(false);
        }

        // For persistent inverted blur, fill entire blur mask with effect
        if (_persistentInvertedBlur)
        {
            // Ensure blur mask texture exists (create default if needed)
            if (_blurMaskTexture == null || _blurMaskBuffer == null)
            {
                // Create a small texture that will cover entire screen when sampled
                int defaultW = 64;
                int defaultH = 64;
                EnsureTexture(defaultW, defaultH);
            }

            // Fill entire mask for full-screen blur
            byte blurAlpha = (byte)(255 * _persistentBlurIntensity);
            Color32 fullBlur = new Color32(255, 255, 255, blurAlpha);
            Array.Fill(_blurMaskBuffer, fullBlur);
            _blurMaskTexture.SetPixels32(_blurMaskBuffer);
            _blurMaskTexture.Apply(false);

            // Also set the blur mask on the material for persistent blur
            if (_blurMaterial != null)
            {
                _blurMaterial.mainTexture = _blurMaskTexture;
                _blurMaterial.SetVector(TextureResolutionId, new Vector4(_texWidth, _texHeight, 0, 0));
            }
        }
        else if (_blurMaskTexture != null && _blurMaskBuffer != null)
        {
            Array.Fill(_blurMaskBuffer, ClearPixel);
            _blurMaskTexture.SetPixels32(_blurMaskBuffer);
            _blurMaskTexture.Apply(false);
        }

        // Clear out-of-bounds color for non-blur effects
        if (!_persistentInvertedBlur && _material != null)
            _material.SetColor(OutOfBoundsColorId, Color.clear);

        _hasBlurEffectThisFrame = false;
        _currentBlurIntensity = 0f;
        _isBlurInverted = false;
        _currentInvertedEffectColor = Color.clear;
        _hasInvertedEffectThisFrame = false;
    }

    /// <summary>
    /// Fully clears all overlays AND resets persistent blur state.
    /// Called by "vibe clear" command to stop all effects.
    /// </summary>
    public void ClearOverlay()
    {
        Debug.Log("[OverlayRenderer] ClearOverlay() called - resetting ALL blur state");

        // Set flag to completely disable blur until explicitly re-enabled
        _blurFullyDisabled = true;

        // CRITICAL: Reset persistent blur state BEFORE ClearVisualOverlays()
        // Otherwise ClearVisualOverlays() sees _persistentInvertedBlur=true and fills mask with blur!
        _persistentInvertedBlur = false;
        _persistentBlurIntensity = 0f;
        _isBlurInverted = false;
        _hasBlurEffectThisFrame = false;
        _currentBlurIntensity = 0f;

        // Now clear visual overlays (will see _persistentInvertedBlur=false and clear the mask)
        ClearVisualOverlays();

        // Disable blur sphere
        if (_blurSphereObj != null)
        {
            _blurSphereObj.SetActive(false);
            Debug.Log("[OverlayRenderer] Blur sphere disabled");
        }

        // Reset blur material properties so blur doesn't persist
        if (_blurMaterial != null)
        {
            _blurMaterial.SetFloat(OutOfBoundsAlphaId, 0f);
            _blurMaterial.SetFloat(GlobalAlphaId, 0f);
            Debug.Log("[OverlayRenderer] Blur material properties reset");
        }

        // Clear out-of-bounds color when overlay is cleared
        if (_material != null)
            _material.SetColor(OutOfBoundsColorId, Color.clear);

        // Hide webcam overlay quad (setting mainTexture=null causes Sprites/Default to render white)
        if (_webcamOverlayQuad != null)
            _webcamOverlayQuad.SetActive(false);

        HideAllLabels();
    }

    private void EnsureTexture(int w, int h)
    {
        if (_overlayTexture != null && _texWidth == w && _texHeight == h)
            return;

        if (_overlayTexture != null)
            Destroy(_overlayTexture);
        if (_blurMaskTexture != null)
            Destroy(_blurMaskTexture);

        _texWidth = w;
        _texHeight = h;
        _overlayTexture = new Texture2D(w, h, TextureFormat.RGBA32, false);
        _overlayTexture.filterMode = FilterMode.Bilinear;
        _overlayTexture.wrapMode = TextureWrapMode.Clamp;
        _pixelBuffer = new Color32[w * h];
        _maskTemp = new byte[w * h];
        _maskSmooth = new byte[w * h];

        // Separate texture for blur mask (used by blur shader)
        _blurMaskTexture = new Texture2D(w, h, TextureFormat.RGBA32, false);
        _blurMaskTexture.filterMode = FilterMode.Bilinear;
        _blurMaskTexture.wrapMode = TextureWrapMode.Clamp;
        _blurMaskBuffer = new Color32[w * h];

        Debug.Log($"[OverlayRenderer] Created overlay texture {w}x{h}");
    }

    private static Color32 GetColor(string assetClass, byte alpha)
    {
        if (string.IsNullOrEmpty(assetClass))
            return new Color32(DefaultColor.r, DefaultColor.g, DefaultColor.b, alpha);

        string key = assetClass.ToLowerInvariant();
        if (key == "screens") key = "screen";
        if (key == "objects") key = "object";

        if (AssetColors.TryGetValue(key, out Color32 c))
            return new Color32(c.r, c.g, c.b, alpha);

        return new Color32(DefaultColor.r, DefaultColor.g, DefaultColor.b, alpha);
    }

    [System.Obsolete("Use DecodeRleIntoMask instead for better performance")]
    private void DecodeRleIntoBuffer(byte[] rleData, int w, int h, Color32 color)
    {
        int totalPixels = w * h;
        int pixelIndex = 0;
        bool isForeground = false;

        for (int i = 0; i + 1 < rleData.Length && pixelIndex < totalPixels; i += 2)
        {
            int runLength = rleData[i] | (rleData[i + 1] << 8);

            if (isForeground)
            {
                int end = Math.Min(pixelIndex + runLength, totalPixels);
                for (int p = pixelIndex; p < end; p++)
                {
                    int rleRow = p / w;
                    int col = p % w;
                    int unityRow = h - 1 - rleRow;
                    int unityIdx = unityRow * w + col;
                    _pixelBuffer[unityIdx] = color;
                }
            }

            pixelIndex += runLength;
            isForeground = !isForeground;
        }
    }

    private void DecodeRleIntoMask(byte[] rleData, int w, int h)
    {
        Array.Clear(_maskTemp, 0, _maskTemp.Length);
        int totalPixels = w * h;
        int pixelIndex = 0;
        bool isForeground = false;

        for (int i = 0; i + 1 < rleData.Length && pixelIndex < totalPixels; i += 2)
        {
            int runLength = rleData[i] | (rleData[i + 1] << 8);

            if (isForeground)
            {
                int end = Math.Min(pixelIndex + runLength, totalPixels);
                for (int p = pixelIndex; p < end; p++)
                {
                    int rleRow = p / w;
                    int col = p % w;
                    int unityRow = h - 1 - rleRow;
                    _maskTemp[unityRow * w + col] = 255;
                }
            }

            pixelIndex += runLength;
            isForeground = !isForeground;
        }
    }

    private void DrawOutlineFromMask(int w, int h, Color32 color, int thickness = -1)
    {
        int width = thickness > 0 ? thickness : outlineWidth;

        // Threshold for boundary detection (50% alpha = geometric edge after smoothing)
        const byte maskThreshold = 128;

        // Soft outline: blend alpha based on distance to edge
        if (softOutlineWidth > 0)
        {
            for (int y = 0; y < h; y++)
            {
                for (int x = 0; x < w; x++)
                {
                    int idx = y * w + x;
                    if (_maskTemp[idx] < maskThreshold) continue;

                    // Find minimum distance to non-mask pixel within search radius
                    int minDist = int.MaxValue;
                    int searchRadius = width + softOutlineWidth;

                    for (int dy = -searchRadius; dy <= searchRadius; dy++)
                    {
                        for (int dx = -searchRadius; dx <= searchRadius; dx++)
                        {
                            int nx = x + dx;
                            int ny = y + dy;

                            if (nx < 0 || nx >= w || ny < 0 || ny >= h || _maskTemp[ny * w + nx] < maskThreshold)
                            {
                                int dist = Math.Max(Math.Abs(dx), Math.Abs(dy)); // Chebyshev distance
                                if (dist < minDist) minDist = dist;
                            }
                        }
                    }

                    // If within outline width, draw with alpha based on soft gradient
                    if (minDist <= width)
                    {
                        // Hard edge portion (always full alpha)
                        _pixelBuffer[idx] = color;
                    }
                    else if (minDist <= width + softOutlineWidth)
                    {
                        // Soft gradient portion
                        float t = (float)(minDist - width) / softOutlineWidth;
                        byte alpha = (byte)(color.a * (1f - t));
                        _pixelBuffer[idx] = new Color32(color.r, color.g, color.b, alpha);
                    }
                }
            }
        }
        else
        {
            // Original hard-edge outline
            for (int y = 0; y < h; y++)
            {
                for (int x = 0; x < w; x++)
                {
                    int idx = y * w + x;
                    if (_maskTemp[idx] < maskThreshold) continue;

                    bool isEdge = false;
                    for (int d = 1; d <= width && !isEdge; d++)
                    {
                        if (y - d < 0  || _maskTemp[(y - d) * w + x] < maskThreshold) isEdge = true;
                        if (y + d >= h || _maskTemp[(y + d) * w + x] < maskThreshold) isEdge = true;
                        if (x - d < 0  || _maskTemp[y * w + (x - d)] < maskThreshold) isEdge = true;
                        if (x + d >= w || _maskTemp[y * w + (x + d)] < maskThreshold) isEdge = true;
                    }

                    if (isEdge)
                        _pixelBuffer[idx] = color;
                }
            }
        }
    }

    // ------------------------------------------------------------------
    // Calibration
    // ------------------------------------------------------------------

    // --- Left controller state (projectionOffset = both eyes) ---
    private bool _lBtnX_prev, _lBtnY_prev;
    private bool _lStickUp_prev, _lStickDown_prev, _lStickLeft_prev, _lStickRight_prev;

    // --- Right controller state (rightEyeOffset = right eye only) ---
    private bool _btnA_prev, _btnB_prev;
    private bool _stickUp_prev, _stickDown_prev, _stickLeft_prev, _stickRight_prev;

    private void HandleCalibrationInput()
    {
        // ===== LEFT CONTROLLER: adjusts projectionOffset (BOTH eyes) =====
        // X = move both eyes RIGHT (+X),  Y = move both eyes LEFT (-X)
        // Left thumbstick up/down/left/right = move both eyes
        bool btnX = OVRInput.Get(OVRInput.Button.One, OVRInput.Controller.LTouch);   // X
        bool btnY = OVRInput.Get(OVRInput.Button.Two, OVRInput.Controller.LTouch);   // Y

        Vector2 lStick = OVRInput.Get(OVRInput.Axis2D.PrimaryThumbstick); // left stick

        bool lStickRight = lStick.x > 0.5f;
        bool lStickLeft = lStick.x < -0.5f;
        bool lStickUp = lStick.y > 0.5f;
        bool lStickDown = lStick.y < -0.5f;

        if (btnX && !_lBtnX_prev)
        {
            projectionOffset.x += calibrationStep;
            LogCalibration("X: both +X", true);
        }
        if (btnY && !_lBtnY_prev)
        {
            projectionOffset.x -= calibrationStep;
            LogCalibration("Y: both -X", true);
        }
        if (lStickUp && !_lStickUp_prev)
        {
            projectionOffset.y -= calibrationStep;
            LogCalibration("LStickUp: both -Y", true);
        }
        if (lStickDown && !_lStickDown_prev)
        {
            projectionOffset.y += calibrationStep;
            LogCalibration("LStickDown: both +Y", true);
        }
        if (lStickRight && !_lStickRight_prev)
        {
            projectionOffset.x += calibrationStep;
            LogCalibration("LStickRight: both +X", true);
        }
        if (lStickLeft && !_lStickLeft_prev)
        {
            projectionOffset.x -= calibrationStep;
            LogCalibration("LStickLeft: both -X", true);
        }

        _lBtnX_prev = btnX;
        _lBtnY_prev = btnY;
        _lStickUp_prev = lStickUp;
        _lStickDown_prev = lStickDown;
        _lStickLeft_prev = lStickLeft;
        _lStickRight_prev = lStickRight;

        // ===== RIGHT CONTROLLER: adjusts rightEyeOffset (right eye ONLY) =====
        // A = move right eye RIGHT (+X),  B = move right eye LEFT (-X)
        // Right thumbstick = move right eye
        bool btnA = OVRInput.Get(OVRInput.Button.One, OVRInput.Controller.RTouch);   // A
        bool btnB = OVRInput.Get(OVRInput.Button.Two, OVRInput.Controller.RTouch);   // B

        Vector2 stick = OVRInput.Get(OVRInput.Axis2D.SecondaryThumbstick); // right stick

        bool stickRight = stick.x > 0.5f;
        bool stickLeft = stick.x < -0.5f;
        bool stickUp = stick.y > 0.5f;
        bool stickDown = stick.y < -0.5f;

        if (btnA && !_btnA_prev)
        {
            rightEyeOffset.x += calibrationStep;
            LogCalibration("A: right +X", false);
        }
        if (btnB && !_btnB_prev)
        {
            rightEyeOffset.x -= calibrationStep;
            LogCalibration("B: right -X", false);
        }
        if (stickUp && !_stickUp_prev)
        {
            rightEyeOffset.y -= calibrationStep;
            LogCalibration("RStickUp: right -Y", false);
        }
        if (stickDown && !_stickDown_prev)
        {
            rightEyeOffset.y += calibrationStep;
            LogCalibration("RStickDown: right +Y", false);
        }
        if (stickRight && !_stickRight_prev)
        {
            rightEyeOffset.x += calibrationStep;
            LogCalibration("RStickRight: right +X", false);
        }
        if (stickLeft && !_stickLeft_prev)
        {
            rightEyeOffset.x -= calibrationStep;
            LogCalibration("RStickLeft: right -X", false);
        }

        _btnA_prev = btnA;
        _btnB_prev = btnB;
        _stickUp_prev = stickUp;
        _stickDown_prev = stickDown;
        _stickLeft_prev = stickLeft;
        _stickRight_prev = stickRight;
    }

    private void LogCalibration(string action, bool isBothEyes)
    {
        if (isBothEyes)
            Debug.Log($"[OverlayRenderer] CALIBRATE {action} => projectionOffset=({projectionOffset.x:F1}, {projectionOffset.y:F1})");
        else
            Debug.Log($"[OverlayRenderer] CALIBRATE {action} => rightEyeOffset=({rightEyeOffset.x:F1}, {rightEyeOffset.y:F1})");
    }

    // ------------------------------------------------------------------
    // 3D Labels
    // ------------------------------------------------------------------

    private float _labelLogTimer;

    private void UpdateLabels(Google.Protobuf.Collections.RepeatedField<SceneSegment> segments)
    {
        if (!_intrinsicsValid || centerEyeAnchor == null)
        {
            if (Time.time - _labelLogTimer > 3f)
            {
                _labelLogTimer = Time.time;
                Debug.Log($"[OverlayRenderer] UpdateLabels BAIL: intrinsicsValid={_intrinsicsValid} centerEye={(centerEyeAnchor != null)}");
            }
            HideAllLabels();
            return;
        }

        Quaternion headRot = _hasCaptureRotation ? _captureRotation : centerEyeAnchor.rotation;

        int labelIdx = 0;
        int segIndex = 0;
        foreach (var seg in segments)
        {
            string label = seg.Label;
            if (string.IsNullOrEmpty(label)) { segIndex++; continue; }

            // Inverse pinhole: normalized center -> pixel -> camera-local direction
            // CenterY is in OpenCV convention (0=top). Flip to match Unity texture
            // Y convention (0=bottom) — the RLE decoder flips mask rows, so the
            // shader's UV.y = 1 - CenterY.
            float px = seg.CenterX * _cachedActualW;
            float py = (1f - seg.CenterY) * _cachedActualH;
            float dx = (px - _cachedPrincipalPoint.x) / _cachedFocalLength.x;
            float dy = (py - _cachedPrincipalPoint.y) / _cachedFocalLength.y;
            Vector3 localDir = new Vector3(dx, dy, 1f).normalized;

            // Camera-local to world direction (world-locked)
            Vector3 worldDir = (headRot * _cachedCameraProjectionRot) * localDir;

            // Position labels at a comfortable reading distance (2m), independent of sphere radius
            float labelDistance = Mathf.Min(sphereRadius * 0.93f, 2f);
            Vector3 labelPos = centerEyeAnchor.position + worldDir * labelDistance;

            // Get or create pooled label
            GameObject labelObj = GetOrCreateLabel(labelIdx);
            labelObj.SetActive(true);

            labelObj.transform.position = labelPos;

            // Billboard: face the user
            labelObj.transform.rotation = Quaternion.LookRotation(
                labelPos - centerEyeAnchor.position, Vector3.up);

            // Set text and color
            var tm = labelObj.GetComponent<TextMesh>();
            tm.text = label;
            tm.characterSize = labelCharSize;
            Color32 c = BrightColors[segIndex % BrightColors.Length];
            tm.color = new Color(c.r / 255f, c.g / 255f, c.b / 255f, 1f);

            if (Time.time - _labelLogTimer > 3f)
            {
                var mr = labelObj.GetComponent<MeshRenderer>();
                Debug.Log($"[OverlayRenderer] Label[{labelIdx}] '{label}' pos={labelPos} " +
                          $"center=({seg.CenterX:F2},{seg.CenterY:F2}) " +
                          $"charSize={tm.characterSize} fontSize={tm.fontSize} " +
                          $"mrEnabled={mr != null && mr.enabled} " +
                          $"matQueue={mr?.material?.renderQueue} " +
                          $"shader={mr?.material?.shader?.name}");
            }

            labelIdx++;
            segIndex++;
        }

        if (Time.time - _labelLogTimer > 3f)
        {
            _labelLogTimer = Time.time;
            Debug.Log($"[OverlayRenderer] Labels placed: {labelIdx} (pool={_labelPool.Count})");
        }

        // Hide unused labels
        for (int i = labelIdx; i < _labelPool.Count; i++)
            _labelPool[i].SetActive(false);
    }

    private void HideAllLabels()
    {
        foreach (var obj in _labelPool)
            if (obj != null) obj.SetActive(false);
    }

    private GameObject GetOrCreateLabel(int index)
    {
        if (index < _labelPool.Count)
            return _labelPool[index];

        var go = new GameObject($"SegLabel_{index}");
        var tm = go.AddComponent<TextMesh>();
        tm.alignment = TextAlignment.Center;
        tm.anchor = TextAnchor.MiddleCenter;
        tm.characterSize = labelCharSize;
        tm.fontSize = 48;

        // Render AFTER overlay sphere (queue 4000) so labels aren't occluded
        var mr = go.GetComponent<MeshRenderer>();
        if (mr != null && mr.material != null)
            mr.material.renderQueue = 4010;

        go.transform.localScale = Vector3.one;

        _labelPool.Add(go);
        return go;
    }

    // ------------------------------------------------------------------

    void OnDestroy()
    {
        if (_overlayTexture != null)
            Destroy(_overlayTexture);
        if (_blurMaskTexture != null)
            Destroy(_blurMaskTexture);
        if (_sphereObj != null)
            Destroy(_sphereObj);
        if (_blurSphereObj != null)
            Destroy(_blurSphereObj);
        if (_blurMaterial != null)
            Destroy(_blurMaterial);
        // Clean up webcam overlay quad
        if (_webcamOverlayQuad != null)
            Destroy(_webcamOverlayQuad);
        if (_webcamOverlayMaterial != null)
            Destroy(_webcamOverlayMaterial);
        if (_blurredWebcamReadback != null)
            Destroy(_blurredWebcamReadback);
        // Clean up two-pass blur resources
        if (_blurTempRT != null)
            _blurTempRT.Release();
        if (_blurredPassthroughRT != null)
            _blurredPassthroughRT.Release();
        if (_blurHorizontalMat != null)
            Destroy(_blurHorizontalMat);
        if (_blurVerticalMat != null)
            Destroy(_blurVerticalMat);
        foreach (var obj in _labelPool)
            if (obj != null) Destroy(obj);
        _labelPool.Clear();

        // Clean up keypoint and depth overlay resources
        _keypointGroups.Clear();
        if (_depthQuad != null) Destroy(_depthQuad);
        if (_depthMaterial != null) Destroy(_depthMaterial);
        if (_depthTexture != null) Destroy(_depthTexture);
    }

    // =========================================================================
    // PHASE 2: KEYPOINT OVERLAY RENDERER
    // Draws skeleton lines and joint dots in world space using GL.
    // Called from SocialSenseClient every time keypoints arrive from server.
    // =========================================================================

    [Header("Keypoint Overlay")]
    [Tooltip("Draw pose/hand/face skeleton lines received from server")]
    public bool showKeypointOverlay = true;

    [Tooltip("Color for skeleton lines")]
    public Color keypointLineColor = new Color(0f, 1f, 0.5f, 0.85f);

    [Tooltip("Color for joint dots")]
    public Color keypointDotColor = Color.white;

    [Tooltip("Width of skeleton lines in world units (scaled by sphere radius)")]
    [Range(0.001f, 0.05f)]
    public float keypointLineWidth = 0.008f;

    [Tooltip("Minimum keypoint visibility to render (0=all, 1=fully visible only)")]
    [Range(0f, 1f)]
    public float keypointVisibilityThreshold = 0.3f;

    // Cached keypoint data received from server
    private readonly List<KeypointOverlay> _keypointGroups = new List<KeypointOverlay>();
    private Material _keypointLineMaterial;

    /// <summary>
    /// Store the latest keypoint overlays received from the server.
    /// Called by SocialSenseClient on every received ServerMessage.
    /// </summary>
    public void UpdateKeypointOverlays(Google.Protobuf.Collections.RepeatedField<KeypointOverlay> keypoints)
    {
        _keypointGroups.Clear();
        foreach (var kpo in keypoints)
            _keypointGroups.Add(kpo);
    }

    /// <summary>
    /// Clears all stored keypoint overlays (e.g. when effects are cleared).
    /// </summary>
    public void ClearKeypointOverlays() => _keypointGroups.Clear();

    private void EnsureKeypointMaterial()
    {
        if (_keypointLineMaterial != null) return;
        // Use Unity's built-in unlit color shader — guaranteed to exist
        _keypointLineMaterial = new Material(Shader.Find("Hidden/Internal-Colored"));
        _keypointLineMaterial.hideFlags = HideFlags.HideAndDontSave;
        _keypointLineMaterial.SetInt("_SrcBlend", (int)UnityEngine.Rendering.BlendMode.SrcAlpha);
        _keypointLineMaterial.SetInt("_DstBlend", (int)UnityEngine.Rendering.BlendMode.OneMinusSrcAlpha);
        _keypointLineMaterial.SetInt("_Cull", (int)UnityEngine.Rendering.CullMode.Off);
        _keypointLineMaterial.SetInt("_ZWrite", 0);
        _keypointLineMaterial.SetInt("_ZTest", (int)UnityEngine.Rendering.CompareFunction.Always);
    }

    /// <summary>
    /// Called from OnPostRender (if camera is set) or from a helper Camera component.
    /// Projects normalized [0,1] keypoint coordinates onto the overlay sphere surface.
    /// </summary>
    public void RenderKeypointOverlaysGL()
    {
        if (!showKeypointOverlay || _keypointGroups.Count == 0 || centerEyeAnchor == null)
            return;

        EnsureKeypointMaterial();
        _keypointLineMaterial.SetPass(0);

        GL.PushMatrix();
        GL.LoadProjectionMatrix(Camera.main != null ? Camera.main.projectionMatrix : Matrix4x4.identity);
        GL.modelview = Camera.main != null ? Camera.main.worldToCameraMatrix : Matrix4x4.identity;

        foreach (var overlay in _keypointGroups)
        {
            foreach (var grp in overlay.Groups)
            {
                var pts = grp.Points;
                var edges = grp.SkeletonEdges;

                // Draw skeleton lines
                GL.Begin(GL.LINES);
                GL.Color(keypointLineColor);
                int numEdgePairs = edges.Count / 2;
                for (int e = 0; e < numEdgePairs; e++)
                {
                    int idxA = edges[e * 2];
                    int idxB = edges[e * 2 + 1];
                    if (idxA < 0 || idxA >= pts.Count || idxB < 0 || idxB >= pts.Count) continue;
                    var ptA = pts[idxA];
                    var ptB = pts[idxB];
                    if (ptA.Visibility < keypointVisibilityThreshold || ptB.Visibility < keypointVisibilityThreshold) continue;

                    Vector3 worldA = KeypointToWorld(ptA.X, ptA.Y);
                    Vector3 worldB = KeypointToWorld(ptB.X, ptB.Y);
                    GL.Vertex(worldA);
                    GL.Vertex(worldB);
                }
                GL.End();

                // Draw joint dots as small quads (GL.QUADS)
                GL.Begin(GL.QUADS);
                GL.Color(keypointDotColor);
                float dotSize = keypointLineWidth * 0.5f * sphereRadius;
                foreach (var pt in pts)
                {
                    if (pt.Visibility < keypointVisibilityThreshold) continue;
                    Vector3 worldPt = KeypointToWorld(pt.X, pt.Y);
                    // Build a camera-facing quad
                    Vector3 camRight = Camera.main != null ? Camera.main.transform.right : Vector3.right;
                    Vector3 camUp = Camera.main != null ? Camera.main.transform.up : Vector3.up;
                    GL.Vertex(worldPt - camRight * dotSize - camUp * dotSize);
                    GL.Vertex(worldPt + camRight * dotSize - camUp * dotSize);
                    GL.Vertex(worldPt + camRight * dotSize + camUp * dotSize);
                    GL.Vertex(worldPt - camRight * dotSize + camUp * dotSize);
                }
                GL.End();
            }
        }

        GL.PopMatrix();
    }

    /// <summary>
    /// Convert normalized screen-space keypoint (x,y in [0,1]) to a world-space
    /// point on the overlay sphere surface, using the same projection math as
    /// the SegmentOverlay shader (pinhole → sphere intersection).
    /// </summary>
    private Vector3 KeypointToWorld(float nx, float ny)
    {
        // Map [0,1] → [-1,1] NDC, then use the stored camera intrinsics to get a ray
        // For simplicity, use a spherical billboard approach:
        // horizontal FOV ≈ 90°, vertical ≈ 74° (Quest 3 passthrough approximate)
        float hFov = Mathf.Deg2Rad * 90f;
        float vFov = Mathf.Deg2Rad * 74f;
        float angleX = (nx - 0.5f) * hFov;
        float angleY = (0.5f - ny) * vFov;  // Y flipped (screen top = +Y)

        // Build ray direction in capture-frame-local space
        Vector3 localDir = new Vector3(
            Mathf.Tan(angleX),
            Mathf.Tan(angleY),
            1f
        ).normalized;

        // Rotate by head capture rotation if available, else current rotation
        Quaternion rot = _hasCaptureRotation ? _captureRotation : centerEyeAnchor.rotation;
        Vector3 worldDir = rot * localDir;

        return centerEyeAnchor.position + worldDir * sphereRadius;
    }

    // =========================================================================
    // PHASE 2: DEPTH OVERLAY RENDERER
    // Displays a JPEG depth colormap received from the server as a semi-transparent
    // overlay quad anchored in front of the user.
    // =========================================================================

    [Header("Depth Overlay")]
    [Tooltip("Show depth colormap received from depth-anything / sapiens")]
    public bool showDepthOverlay = true;

    [Tooltip("Alpha of the depth overlay quad (0=invisible, 1=fully opaque)")]
    [Range(0f, 1f)]
    public float depthOverlayAlpha = 0.55f;

    [Tooltip("Width of the depth overlay quad in meters (placed 2m in front)")]
    public float depthQuadWidth = 1.0f;

    [Tooltip("Distance in front of user to place the depth quad (meters)")]
    public float depthQuadDistance = 2.0f;

    private GameObject _depthQuad;
    private Material _depthMaterial;
    private Texture2D _depthTexture;
    private bool _depthOverlayActive = false;

    /// <summary>
    /// Decode the JPEG depth colormap from the server and display it as an overlay quad.
    /// Called from SocialSenseClient on every ServerMessage that contains depth data.
    /// Pass null to hide the depth overlay.
    /// </summary>
    public void UpdateDepthOverlay(DepthOverlay depthData)
    {
        if (depthData == null || depthData.DepthRgb == null || depthData.DepthRgb.Length == 0)
        {
            if (_depthQuad != null) _depthQuad.SetActive(false);
            _depthOverlayActive = false;
            return;
        }

        if (!showDepthOverlay)
        {
            if (_depthQuad != null) _depthQuad.SetActive(false);
            return;
        }

        // Lazy create the quad and material
        if (_depthQuad == null)
        {
            _depthQuad = GameObject.CreatePrimitive(PrimitiveType.Quad);
            _depthQuad.name = "DepthOverlayQuad";
            Destroy(_depthQuad.GetComponent<Collider>());

            _depthMaterial = new Material(Shader.Find("Unlit/Transparent"));
            _depthMaterial.color = new Color(1f, 1f, 1f, depthOverlayAlpha);
            _depthQuad.GetComponent<Renderer>().material = _depthMaterial;
        }

        // Decode JPEG bytes into texture
        byte[] jpegBytes = depthData.DepthRgb.ToByteArray();
        if (_depthTexture == null || _depthTexture.width != depthData.Width || _depthTexture.height != depthData.Height)
        {
            if (_depthTexture != null) Destroy(_depthTexture);
            _depthTexture = new Texture2D(
                Mathf.Max(1, depthData.Width),
                Mathf.Max(1, depthData.Height),
                TextureFormat.RGB24, false);
        }
        _depthTexture.LoadImage(jpegBytes);  // LoadImage auto-resizes for JPEGs
        _depthMaterial.mainTexture = _depthTexture;
        _depthMaterial.color = new Color(1f, 1f, 1f, depthOverlayAlpha);

        // Position the quad in front of the user (world-locked to current head pose)
        if (centerEyeAnchor != null)
        {
            float aspect = depthData.Width > 0 && depthData.Height > 0
                ? (float)depthData.Width / depthData.Height
                : 1f;
            float quadHeight = depthQuadWidth / aspect;

            _depthQuad.transform.position = centerEyeAnchor.position
                + centerEyeAnchor.forward * depthQuadDistance
                + centerEyeAnchor.up * (quadHeight * 0.15f);  // slightly up from center
            _depthQuad.transform.rotation = centerEyeAnchor.rotation;
            _depthQuad.transform.localScale = new Vector3(depthQuadWidth, quadHeight, 1f);
        }

        _depthQuad.SetActive(true);
        _depthOverlayActive = true;
    }

    /// <summary>
    /// Hide the depth overlay (e.g. when effects are cleared).
    /// </summary>
    public void ClearDepthOverlay()
    {
        if (_depthQuad != null) _depthQuad.SetActive(false);
        _depthOverlayActive = false;
    }
}
